@echo off
setlocal
pushd "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
  py -3 -c "import sys; assert sys.version_info.major == 3" >nul 2>nul
  if not errorlevel 1 goto run_py
)
where python >nul 2>nul
if not errorlevel 1 (
  python -c "import sys; assert sys.version_info.major == 3" >nul 2>nul
  if not errorlevel 1 goto run_python
)
echo Python 3 is required. Install Python 3 and enable Add Python to PATH.
echo https://www.python.org/downloads/
pause
popd
exit /b 1
:run_py
py -3 "%~dp0IDF_Thumbnail_Studio.py"
goto finish
:run_python
python "%~dp0IDF_Thumbnail_Studio.py"
:finish
if errorlevel 1 pause
popd
endlocal
