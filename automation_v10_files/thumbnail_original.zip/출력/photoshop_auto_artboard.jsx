
// ═══════════════════════════════════════════════════════
//  포토샵 자동화 스크립트 — 아트보드 버전
// ═══════════════════════════════════════════════════════
#target photoshop

var CONFIG = {
  psd:      "C:/Users/User/Desktop/인동Fn/리사이징 자동화/files_artboard/Total_artboard.psd",
  img600:   "C:/Users/User/Desktop/인동Fn/리사이징 자동화/new/출력/dl_img_7579770255.jpg",
  imgP:     "C:/Users/User/Desktop/인동Fn/리사이징 자동화/new/출력/dl_img_7579770255.jpg",
  imgCommon: "C:/Users/User/Desktop/인동Fn/리사이징 자동화/new/출력/dl_img_7579770255.jpg",
  imgSSF1:  "C:/Users/User/Desktop/인동Fn/리사이징 자동화/new/출력/dl_img_7579770255.jpg",
  imgSSF2:  "C:/Users/User/Desktop/인동Fn/리사이징 자동화/new/출력/dl_img_6143117823.jpg",
  imgSSF3:  "C:/Users/User/Desktop/인동Fn/리사이징 자동화/new/출력/dl_img_5928323717.jpg",
  img1200:  "C:/Users/User/Desktop/인동Fn/리사이징 자동화/new/출력/dl_img_7579770255.jpg",
  logoName: "shesmiss_logo",
  outputDir:"C:/Users/User/Desktop/인동Fn/리사이징 자동화/new/출력",
  colorMap: {}
};

// ── 유틸 ──────────────────────────────────────────────
function findLayerByName(layers, name) {
  for (var i = 0; i < layers.length; i++) {
    if (layers[i].name === name) return layers[i];
    if (layers[i].typename === 'LayerSet') {
      var found = findLayerByName(layers[i].layers, name);
      if (found) return found;
    }
  }
  return null;
}

function findGroup(layers, name) {
  for (var i = 0; i < layers.length; i++) {
    if (layers[i].name === name && layers[i].typename === 'LayerSet')
      return layers[i];
  }
  return null;
}

function findArtboard(doc, name) {
  for (var i = 0; i < doc.layers.length; i++) {
    if (doc.layers[i].name === name) return doc.layers[i];
  }
  return null;
}

// ── Color Overlay 적용 (Photoshop 27 호환) ────────────
function setColorOverlay(layer, r, g, b) {
  app.activeDocument.activeLayer = layer;
  var idsetd = charIDToTypeID("setd");
  var desc1 = new ActionDescriptor();
  var ref1 = new ActionReference();
  ref1.putEnumerated(charIDToTypeID("Lyr "), charIDToTypeID("Ordn"), charIDToTypeID("Trgt"));
  desc1.putReference(charIDToTypeID("null"), ref1);
  var desc2 = new ActionDescriptor();
  var desc3 = new ActionDescriptor();
  desc3.putBoolean(charIDToTypeID("enab"), true);
  desc3.putEnumerated(charIDToTypeID("Md  "), charIDToTypeID("BlnM"), charIDToTypeID("Nrml"));
  desc3.putUnitDouble(charIDToTypeID("Opct"), charIDToTypeID("#Prc"), 100.0);
  var desc4 = new ActionDescriptor();
  desc4.putDouble(charIDToTypeID("Rd  "), r);
  desc4.putDouble(charIDToTypeID("Grn "), g);
  desc4.putDouble(charIDToTypeID("Bl  "), b);
  desc3.putObject(charIDToTypeID("Clr "), charIDToTypeID("RGBC"), desc4);
  desc2.putObject(charIDToTypeID("SoFi"), charIDToTypeID("SoFi"), desc3);
  desc1.putObject(charIDToTypeID("T   "), charIDToTypeID("Lefx"), desc2);
  executeAction(idsetd, desc1, DialogModes.NO);
}

// ── 로고 설정 ─────────────────────────────────────────
function setLogo(abLayers) {
  var logoNames = {"list_logo":1,"sistina_logo":1,"shesmiss_logo":1};
  var logoGroup = findGroup(abLayers, "로고");
  if (!logoGroup) return;
  for (var i = 0; i < logoGroup.layers.length; i++) {
    var ll = logoGroup.layers[i];
    if (logoNames[ll.name]) {
      ll.visible = (ll.name === CONFIG.logoName);
    }
  }
}

// ── 컬러 설정 ─────────────────────────────────────────
function setColors(abLayers) {
  var colorGroup = findGroup(abLayers, "컬러링");
  if (!colorGroup) return;
  for (var i = 0; i < colorGroup.layers.length; i++) {
    colorGroup.layers[i].visible = false;
  }
  for (var layerNum in CONFIG.colorMap) {
    if (!CONFIG.colorMap.hasOwnProperty(layerNum)) continue;
    var hex = CONFIG.colorMap[layerNum].replace('#','');
    var r = parseInt(hex.substr(0,2),16);
    var g = parseInt(hex.substr(2,2),16);
    var b = parseInt(hex.substr(4,2),16);
    var layer = findLayerByName(colorGroup.layers, layerNum);
    if (!layer) continue;
    layer.visible = true;
    try { setColorOverlay(layer, r, g, b); } catch(e) {}
  }
}

// ── 이미지 배치 ───────────────────────────────────────
function placeImage(doc, abLayer, imgPath) {
  if (!imgPath || imgPath === "") return;
  var productGroup = findGroup(abLayer.layers, "제품컷");
  var old = findLayerByName(abLayer.layers, "제품이미지");
  if (old) old.remove();
  doc.activeLayer = abLayer;
  var placeFile = new File(imgPath);
  var placeDesc = new ActionDescriptor();
  placeDesc.putPath(charIDToTypeID("null"), placeFile);
  placeDesc.putEnumerated(charIDToTypeID("FTcs"), charIDToTypeID("QCSt"), charIDToTypeID("Qcsa"));
  executeAction(charIDToTypeID("Plc "), placeDesc, DialogModes.NO);
  var placed = doc.activeLayer;
  try { placed.rasterize(RasterizeType.ENTIRELAYER); } catch(e) {}
  placed.name = "제품이미지";
  if (productGroup) placed.move(productGroup, ElementPlacement.PLACEATBEGINNING);
  var abH = abLayer.bounds[3].as('px') - abLayer.bounds[1].as('px');
  var layerH = placed.bounds[3].as('px') - placed.bounds[1].as('px');
  if (layerH > 0) {
    var scale = (abH / layerH) * 100;
    placed.resize(scale, scale, AnchorPosition.MIDDLECENTER);
  }
}

// ── PSD로 저장 ────────────────────────────────────────
function saveAsPsd(doc, outPath) {
  var copy = doc.duplicate();
  var opts = new PhotoshopSaveOptions();
  opts.layers = true;
  opts.embedColorProfile = true;
  copy.saveAs(new File(outPath), opts, true);
  copy.close(SaveOptions.DONOTSAVECHANGES);
}

// ══════════════════════════════════════════════════════
//  메인 실행
// ══════════════════════════════════════════════════════
var doc = app.open(new File(CONFIG.psd));
var outFolder = new Folder(CONFIG.outputDir);
if (!outFolder.exists) outFolder.create();


// ── 아트보드: 600 ──────────────────────────────────────
var ab600 = findArtboard(doc, "600");
if (ab600) {
  setLogo(ab600.layers);
  setColors(ab600.layers);
}

// ── 아트보드: P ────────────────────────────────────────
var abP = findArtboard(doc, "P");
if (abP) {
  setLogo(abP.layers);
  setColors(abP.layers);
}

// ── 아트보드: SSF_01~03 (각 아트보드에 이미지 배치) ─────
var ssfMap = [
  { name: "SSF_01", img: CONFIG.imgSSF1, layer: "img_01" },
  { name: "SSF_02", img: CONFIG.imgSSF2, layer: "img_02" },
  { name: "SSF_03", img: CONFIG.imgSSF3, layer: "img_03" }
];

for (var si = 0; si < ssfMap.length; si++) {
  var abSSF = findArtboard(doc, ssfMap[si].name);
  if (!abSSF || !ssfMap[si].img || ssfMap[si].img === "") continue;

  // 기존 이미지 레이어 제거
  var oldSSF = findLayerByName(abSSF.layers, ssfMap[si].layer + "_img");
  if (oldSSF) oldSSF.remove();

  // 가이드 레이어 찾아서 크기 파악
  var guideLayer = findLayerByName(abSSF.layers, ssfMap[si].layer);
  var abBounds = abSSF.bounds;
  var abX = abBounds[0].as('px');
  var abY = abBounds[1].as('px');
  var abW = abBounds[2].as('px') - abX;
  var abH = abBounds[3].as('px') - abY;

  if (guideLayer) {
    var gb = guideLayer.bounds;
    var gW = gb[2].as('px') - gb[0].as('px');
    var gH = gb[3].as('px') - gb[1].as('px');
    if (gW > 0 && gH > 0) {
      abW = gW; abH = gH;
      abX = gb[0].as('px'); abY = gb[1].as('px');
    }
    guideLayer.visible = false;
  }

  // 이미지 Place
  doc.activeLayer = abSSF;
  var placeFileSSF = new File(ssfMap[si].img);
  var placeDescSSF = new ActionDescriptor();
  placeDescSSF.putPath(charIDToTypeID("null"), placeFileSSF);
  placeDescSSF.putEnumerated(charIDToTypeID("FTcs"), charIDToTypeID("QCSt"), charIDToTypeID("Qcsa"));
  executeAction(charIDToTypeID("Plc "), placeDescSSF, DialogModes.NO);
  var placedSSF = doc.activeLayer;
  try { placedSSF.rasterize(RasterizeType.ENTIRELAYER); } catch(e) {}
  placedSSF.name = ssfMap[si].layer + "_img";

  // 크기 맞춰 리사이징
  var pW = placedSSF.bounds[2].as('px') - placedSSF.bounds[0].as('px');
  var pH = placedSSF.bounds[3].as('px') - placedSSF.bounds[1].as('px');
  if (pW > 0 && pH > 0) {
    var scaleW = (abW / pW) * 100;
    var scaleH = (abH / pH) * 100;
    var scaleSSF = Math.max(scaleW, scaleH);
    placedSSF.resize(scaleSSF, scaleSSF, AnchorPosition.MIDDLECENTER);
  }

  // 아트보드 중앙으로 이동
  var pCX = (placedSSF.bounds[0].as('px') + placedSSF.bounds[2].as('px')) / 2;
  var pCY = (placedSSF.bounds[1].as('px') + placedSSF.bounds[3].as('px')) / 2;
  var aCX = abX + abW / 2;
  var aCY = abY + abH / 2;
  placedSSF.translate(aCX - pCX, aCY - pCY);
}


// ── img_smart 스마트 오브젝트 열어서 이미지 배치 (한 번만!) ──
if (CONFIG.imgCommon && CONFIG.imgCommon !== "") {
  var ab600tmp = findArtboard(doc, "600");
  var smartObj = ab600tmp ? findLayerByName(ab600tmp.layers, "img_smart") : null;

  if (smartObj) {
    doc.activeLayer = smartObj;

    // runMenuItem 방식으로 스마트 오브젝트 열기
    runMenuItem(stringIDToTypeID('placedLayerEditContents'));
    var smartDoc = app.activeDocument;

    // 내부의 img 레이어 찾기 (크기 기준)
    var imgGuide = findLayerByName(smartDoc.layers, "img");
    var iX = 0, iY = 0;
    var iW = smartDoc.width.as('px'), iH = smartDoc.height.as('px');
    if (imgGuide) {
      var ib = imgGuide.bounds;
      var bW = ib[2].as('px') - ib[0].as('px');
      var bH = ib[3].as('px') - ib[1].as('px');
      if (bW > 0 && bH > 0) {
        iX = ib[0].as('px'); iY = ib[1].as('px');
        iW = bW; iH = bH;
      }
      imgGuide.visible = false;
    }

    // 기존 배치이미지 제거
    var oldImg = findLayerByName(smartDoc.layers, "배치이미지");
    if (oldImg) oldImg.remove();

    // 이미지 Place
    var placeFileSmart = new File(CONFIG.imgCommon);
    var placeDescSmart = new ActionDescriptor();
    placeDescSmart.putPath(charIDToTypeID("null"), placeFileSmart);
    placeDescSmart.putEnumerated(charIDToTypeID("FTcs"), charIDToTypeID("QCSt"), charIDToTypeID("Qcsa"));
    executeAction(charIDToTypeID("Plc "), placeDescSmart, DialogModes.NO);
    var placedSmart = smartDoc.activeLayer;
    try { placedSmart.rasterize(RasterizeType.ENTIRELAYER); } catch(e) {}
    placedSmart.name = "배치이미지";

    // img 레이어 크기에 맞게 리사이징
    var pWs = placedSmart.bounds[2].as('px') - placedSmart.bounds[0].as('px');
    var pHs = placedSmart.bounds[3].as('px') - placedSmart.bounds[1].as('px');
    if (pWs > 0 && pHs > 0) {
      var scaleWs = (iW / pWs) * 100;
      var scaleHs = (iH / pHs) * 100;
      var scaleSmart = Math.max(scaleWs, scaleHs);
      placedSmart.resize(scaleSmart, scaleSmart, AnchorPosition.MIDDLECENTER);
    }

    // 중앙 정렬
    var pCXs = (placedSmart.bounds[0].as('px') + placedSmart.bounds[2].as('px')) / 2;
    var pCYs = (placedSmart.bounds[1].as('px') + placedSmart.bounds[3].as('px')) / 2;
    placedSmart.translate((iX + iW/2) - pCXs, (iY + iH/2) - pCYs);

    // 스마트 오브젝트 저장 (닫지 않고 열린 채로 유지)
    smartDoc.save();
    app.activeDocument = doc;
  }
}
// 모든 작업 완료 후 스마트 오브젝트 다시 열기
var ab600final = findArtboard(doc, "600");
var smartObjFinal = ab600final ? findLayerByName(ab600final.layers, "img_smart") : null;
if (smartObjFinal) {
  doc.activeLayer = smartObjFinal;
  runMenuItem(stringIDToTypeID('placedLayerEditContents'));
}

alert("✅ 완료!\n저장 위치: " + CONFIG.outputDir + "/아트보드_작업.psd");
