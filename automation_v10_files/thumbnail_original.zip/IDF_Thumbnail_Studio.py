# -*- coding: utf-8 -*-
"""IDF STUDIO: standard and W Concept resizing. Python 3 standard library only."""
import os
import re
import json
import urllib.request
import urllib.parse
from http.server import HTTPServer, BaseHTTPRequestHandler
from html.parser import HTMLParser

# ── 색상 이름 → HEX 매핑 ──────────────────────────────
COLOR_NAME_MAP = {
    "white": "#FFFFFF", "off white": "#F0EDE6", "off-white": "#F0EDE6",
    "ivory": "#FFFFF0", "cream": "#FFFDD0", "ecru": "#F5F0E8",
    "beige": "#C8AD8F", "light beige": "#D9C9B0", "dark beige": "#A08060",
    "sand": "#C2B280", "camel": "#C19A6B", "khaki": "#8B864E",
    "light khaki": "#BDB76B", "olive": "#808000", "olive green": "#6B7030",
    "natural": "#D4C5A9",
    "pink": "#FFB6C1", "light pink": "#FFD1DC", "hot pink": "#FF69B4",
    "rose": "#C0507A", "dusty rose": "#C9A0A0", "blush": "#DE9090",
    "mauve": "#B784A7", "coral": "#FF6B6B", "salmon": "#FA8072", "peach": "#FFCBA4",
    "red": "#CC2200", "dark red": "#8B0000", "burgundy": "#800020",
    "wine": "#722F37", "maroon": "#800000", "brick": "#9C3A2E", "rust": "#B7410E",
    "orange": "#FF6600", "yellow": "#FFE066", "mustard": "#C8A000",
    "gold": "#C8A800", "lemon": "#FFF44F",
    "green": "#228B22", "light green": "#90EE90", "dark green": "#006400",
    "mint": "#98D8C8", "sage": "#8A9068", "emerald": "#50C878", "lime": "#32CD32",
    "blue": "#4169E1", "light blue": "#ADD8E6", "sky blue": "#87CEEB",
    "sky": "#87CEEB", "navy": "#001F5B", "navy blue": "#001F5B",
    "dark navy": "#000D2E", "cobalt": "#0047AB", "baby blue": "#89CFF0",
    "denim": "#1560BD", "denim blue": "#1560BD", "indigo": "#3A3070",
    "purple": "#800080", "lavender": "#C8C0E0", "violet": "#8F00FF",
    "lilac": "#C8A2C8", "plum": "#8B4585",
    "brown": "#8B4513", "light brown": "#C68642", "dark brown": "#5C3317",
    "chocolate": "#7B3F00", "coffee": "#6F4E37", "tan": "#D2B48C", "mocha": "#8B6A4F",
    "gray": "#808080", "grey": "#808080", "light gray": "#D3D3D3",
    "light grey": "#D3D3D3", "dark gray": "#404040", "dark grey": "#404040",
    "charcoal": "#36454F", "silver": "#C0C0C0", "ash": "#B2BEB5",
    "melange": "#AAAAAA", "melange gray": "#A8A8A8", "melange brown": "#9A8070",
    "black": "#1A1A1A", "jet black": "#0A0A0A",
}

def color_name_to_hex(name):
    key = name.strip().lower()
    if key in COLOR_NAME_MAP:
        return COLOR_NAME_MAP[key]
    for k, v in COLOR_NAME_MAP.items():
        if k in key or key in k:
            return v
    return None

# ── IDF몰 색상 파서 ───────────────────────────────────
class IDFColorParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self._bg_re = re.compile(
            r'background(?:-color)?\s*:\s*(#[0-9a-fA-F]{3,6}|rgb\([^)]+\)|rgba\([^)]+\))',
            re.IGNORECASE)
        self._color_label_re = re.compile(r'색상', re.IGNORECASE)
        self._in_td = False
        self._prev_was_color_label = False
        self._td_text = ''
        self._color_names_from_table = []
        self._inline_swatches = []

    def handle_starttag(self, tag, attrs):
        attrs_dict = dict(attrs)
        style = attrs_dict.get('style', '')
        if style:
            m = self._bg_re.search(style)
            if m:
                raw = m.group(1).strip()
                hex_val = self._to_hex(raw)
                if hex_val and hex_val.upper() not in ('#FFFFFF','#000000','#FEFEFE','#F5F5F5','#EEEEEE'):
                    self._inline_swatches.append(hex_val.upper())
        if tag == 'td':
            self._in_td = True
            self._td_text = ''

    def handle_endtag(self, tag):
        if tag == 'td':
            txt = self._td_text.strip()
            if self._color_label_re.search(txt) and len(txt) < 10:
                self._prev_was_color_label = True
            elif self._prev_was_color_label and txt:
                for name in re.split(r'[,/]', txt):
                    name = name.strip()
                    if 1 < len(name) < 40:
                        self._color_names_from_table.append(name)
                self._prev_was_color_label = False
            else:
                self._prev_was_color_label = False
            self._in_td = False

    def handle_data(self, data):
        if self._in_td:
            self._td_text += data

    def _to_hex(self, c):
        if c.startswith('#'):
            if len(c) == 4:
                c = '#' + ''.join(x*2 for x in c[1:])
            if len(c) == 7:
                return c.upper()
        m = re.match(r'rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)', c)
        if m:
            return '#{:02X}{:02X}{:02X}'.format(*map(int, m.groups()))
        return None

    def get_results(self):
        results = []
        seen = set()
        for name in self._color_names_from_table:
            key = name.upper()
            if key in seen:
                continue
            seen.add(key)
            hex_val = color_name_to_hex(name)
            results.append({'name': name, 'hex': hex_val or '#CCCCCC', 'matched': hex_val is not None})
        for hex_val in self._inline_swatches:
            if hex_val in seen:
                continue
            seen.add(hex_val)
            results.append({'name': hex_val, 'hex': hex_val, 'matched': True})
        return results

def fetch_colors(url):
    try:
        req = urllib.request.Request(url, headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
            'Accept-Language': 'ko-KR,ko;q=0.9',
            'Referer': 'https://idfmall.co.kr/',
        })
        with urllib.request.urlopen(req, timeout=15) as resp:
            html = resp.read().decode('utf-8', errors='ignore')
        parser = IDFColorParser()
        parser.feed(html)
        results = parser.get_results()
        return {'colors': results, 'count': len(results)}
    except Exception as e:
        return {'error': str(e), 'colors': []}

def fetch_images(url):
    try:
        import gzip as _gz, http.cookiejar, ssl
        ctx = ssl.create_default_context()
        ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
        cj = http.cookiejar.CookieJar()
        opener = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(cj),
            urllib.request.HTTPSHandler(context=ctx))
        opener.addheaders = [
            ('User-Agent','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'),
            ('Accept','text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'),
            ('Accept-Language','ko-KR,ko;q=0.9'),
            ('Accept-Encoding','gzip, deflate'),
            ('Referer','https://idfmall.co.kr/'),
        ]
        resp = opener.open(url, timeout=15)
        raw = resp.read()
        try: html = _gz.decompress(raw).decode('utf-8', errors='ignore')
        except: html = raw.decode('utf-8', errors='ignore')
        p1 = re.findall(r'https?://[^\s"\'\\<>]*?/(?:extra/)?small/[^\s"\'\\<>]+\.(?:jpg|jpeg|png|webp)', html)
        p2 = re.findall(r"""[\"']([^\"']*?/(?:extra/)?small/[^\"']+\.(?:jpg|jpeg|png|webp))[\"']""", html)
        p3 = re.findall(r'https?://ecimg\.cafe24img\.com/[^\s"\'\\<>]+\.(?:jpg|jpeg|png|webp)', html)
        p4 = re.findall(r'https?://[^\s"\'\\<>]*?web/product/[^\s"\'\\<>]+\.(?:jpg|jpeg|png|webp)', html)
        base = ''
        bm = re.match(r'(https?://[^/]+)', url)
        if bm: base = bm.group(1)
        imgs = list(p1) + list(p3) + list(p4)
        for p in p2:
            if p.startswith('http'):
                imgs.append(p)
            elif p.startswith('//'):
                imgs.append('https:' + p)
            elif p.startswith('/idfmall.co.kr/'):
                imgs.append('https://' + p.lstrip('/'))
            elif p.startswith('/web/'):
                imgs.append(base + p)
            elif p.startswith('/') and base:
                imgs.append(base + p)
            else:
                imgs.append(p)
        skip = ['logo','icon','banner','button','btn','arrow','loading','empty','bg_','common','upload/category','upload/custom','facto/','/big/']
        seen, finals, fnames = [], [], set()
        for s in imgs:
            if not s or s in seen: continue
            if any(k in s.lower() for k in skip): continue
            seen.append(s)
        seen.sort(key=lambda x: 0 if 'extra/small' in x else 1)
        for s in seen:
            s2 = re.sub(r'https?://[^/]*poxo\.com/idfmall/', 'https://idfmall.co.kr/', s)
            fn = s2.split('/')[-1].lower()
            if fn in fnames: continue
            fnames.add(fn); finals.append(s2)
        return {'ok':True,'images':finals[:6],'total':len(finals)}
    except Exception as e:
        return {'ok':False,'error':str(e),'images':[]}

# ── 이미지 URL 다운로드 ───────────────────────────────
def resolve_image_path(path_or_url, output_dir, download_cache=None):
    p = str(path_or_url or '').strip().strip('"').strip("'")
    if not p:
        return ''

    # 같은 URL을 여러 입력칸에서 사용할 경우 한 번만 다운로드
    if download_cache is not None and p in download_cache:
        return download_cache[p]

    if p.startswith('//'):
        p = 'https:' + p
    elif p.startswith('/idfmall.co.kr/'):
        p = 'https://' + p.lstrip('/')

    if p.startswith('http://') or p.startswith('https://'):
        try:
            import ssl
            import http.cookiejar

            os.makedirs(output_dir, exist_ok=True)
            parsed = urllib.parse.urlparse(p)
            ext = os.path.splitext(parsed.path)[1].lower().lstrip('.')
            if ext not in ('jpg', 'jpeg', 'png', 'gif', 'webp'):
                ext = 'jpg'

            filename = 'dl_img_' + str(abs(hash(p)))[:10] + '.' + ext
            save_path = os.path.join(output_dir, filename)

            # IDF몰 이미지 서버의 SSL/Referer/쿠키 조건을 함께 처리
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            cj = http.cookiejar.CookieJar()
            opener = urllib.request.build_opener(
                urllib.request.HTTPCookieProcessor(cj),
                urllib.request.HTTPSHandler(context=ctx)
            )
            opener.addheaders = [
                ('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'),
                ('Accept', 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8'),
                ('Accept-Language', 'ko-KR,ko;q=0.9'),
                ('Referer', 'https://idfmall.co.kr/'),
            ]

            with opener.open(p, timeout=30) as resp:
                data = resp.read()

            if not data:
                return {'error': '이미지 다운로드 실패: 빈 파일이 반환되었습니다. URL: ' + p}

            with open(save_path, 'wb') as f:
                f.write(data)

            result = save_path.replace('\\', '/')
            if download_cache is not None:
                download_cache[p] = result
            return result
        except Exception as e:
            return {'error': '이미지 다운로드 실패: ' + str(e) + ' / URL: ' + p}
    else:
        result = p.replace('\\', '/')
        if download_cache is not None:
            download_cache[p] = result
        return result

# ── JSX 생성 (아트보드 버전) ──────────────────────────
def build_jsx_standard(config):
    def clean(p):
        return p.strip().strip('"').strip("'").replace('\\', '/')

    psd      = clean(config.get('psd', ''))
    img_600  = clean(config.get('img_600', ''))
    img_p    = clean(config.get('img_p', ''))
    img_common = clean(config.get('imgCommon', ''))
    img_ssf1 = clean(config.get('img_ssf1', ''))
    img_ssf2 = clean(config.get('img_ssf2', ''))
    img_ssf3 = clean(config.get('img_ssf3', ''))
    img_1200 = clean(config.get('img_1200', ''))
    logo     = config.get('logo', 'list_logo')
    out_dir  = clean(config.get('output_dir', 'C:/Output'))
    color_map = json.dumps(config.get('color_assignments', {}))

    jsx = """
// ═══════════════════════════════════════════════════════
//  포토샵 자동화 스크립트 — 아트보드 버전
// ═══════════════════════════════════════════════════════
#target photoshop

var CONFIG = {
  psd:      "%(psd)s",
  img600:   "%(img_600)s",
  imgP:     "%(img_p)s",
  imgCommon: "%(img_common)s",
  imgSSF1:  "%(img_ssf1)s",
  imgSSF2:  "%(img_ssf2)s",
  imgSSF3:  "%(img_ssf3)s",
  img1200:  "%(img_1200)s",
  logoName: "%(logo)s",
  outputDir:"%(out_dir)s",
  colorMap: %(color_map)s
};

// ── 유틸 ──────────────────────────────────────────────
function findLayerByName(layers, name) {
  for (var i = 0; i < layers.length; i++) {
    if (layers[i].name === name) return layers[i];
    if (layers[i].typename === 'LayerSet') {
      var found = findLayerByName(layers[i].layers, name);
      if (found) return found;
    }
  }
  return null;
}

function findGroup(layers, name) {
  for (var i = 0; i < layers.length; i++) {
    if (layers[i].name === name && layers[i].typename === 'LayerSet')
      return layers[i];
  }
  return null;
}

function findArtboard(doc, name) {
  for (var i = 0; i < doc.layers.length; i++) {
    if (doc.layers[i].name === name) return doc.layers[i];
  }
  return null;
}

// ── Color Overlay 적용 (Photoshop 27 호환) ────────────
function setColorOverlay(layer, r, g, b) {
  app.activeDocument.activeLayer = layer;
  var idsetd = charIDToTypeID("setd");
  var desc1 = new ActionDescriptor();
  var ref1 = new ActionReference();
  ref1.putEnumerated(charIDToTypeID("Lyr "), charIDToTypeID("Ordn"), charIDToTypeID("Trgt"));
  desc1.putReference(charIDToTypeID("null"), ref1);
  var desc2 = new ActionDescriptor();
  var desc3 = new ActionDescriptor();
  desc3.putBoolean(charIDToTypeID("enab"), true);
  desc3.putEnumerated(charIDToTypeID("Md  "), charIDToTypeID("BlnM"), charIDToTypeID("Nrml"));
  desc3.putUnitDouble(charIDToTypeID("Opct"), charIDToTypeID("#Prc"), 100.0);
  var desc4 = new ActionDescriptor();
  desc4.putDouble(charIDToTypeID("Rd  "), r);
  desc4.putDouble(charIDToTypeID("Grn "), g);
  desc4.putDouble(charIDToTypeID("Bl  "), b);
  desc3.putObject(charIDToTypeID("Clr "), charIDToTypeID("RGBC"), desc4);
  desc2.putObject(charIDToTypeID("SoFi"), charIDToTypeID("SoFi"), desc3);
  desc1.putObject(charIDToTypeID("T   "), charIDToTypeID("Lefx"), desc2);
  executeAction(idsetd, desc1, DialogModes.NO);
}

// ── 로고 설정 ─────────────────────────────────────────
function setLogo(abLayers) {
  var logoNames = {"list_logo":1,"sistina_logo":1,"shesmiss_logo":1};
  var logoGroup = findGroup(abLayers, "로고");
  if (!logoGroup) return;
  for (var i = 0; i < logoGroup.layers.length; i++) {
    var ll = logoGroup.layers[i];
    if (logoNames[ll.name]) {
      ll.visible = (ll.name === CONFIG.logoName);
    }
  }
}

// ── 컬러 설정 ─────────────────────────────────────────
function setColors(abLayers) {
  var colorGroup = findGroup(abLayers, "컬러링");
  if (!colorGroup) return;
  for (var i = 0; i < colorGroup.layers.length; i++) {
    colorGroup.layers[i].visible = false;
  }
  for (var layerNum in CONFIG.colorMap) {
    if (!CONFIG.colorMap.hasOwnProperty(layerNum)) continue;
    var hex = CONFIG.colorMap[layerNum].replace('#','');
    var r = parseInt(hex.substr(0,2),16);
    var g = parseInt(hex.substr(2,2),16);
    var b = parseInt(hex.substr(4,2),16);
    var layer = findLayerByName(colorGroup.layers, layerNum);
    if (!layer) continue;
    layer.visible = true;
    try { setColorOverlay(layer, r, g, b); } catch(e) {}
  }
}

// ── 이미지 배치 ───────────────────────────────────────
function placeImage(doc, abLayer, imgPath) {
  if (!imgPath || imgPath === "") return;
  var productGroup = findGroup(abLayer.layers, "제품컷");
  var old = findLayerByName(abLayer.layers, "제품이미지");
  if (old) old.remove();
  doc.activeLayer = abLayer;
  var placeFile = new File(imgPath);
  var placeDesc = new ActionDescriptor();
  placeDesc.putPath(charIDToTypeID("null"), placeFile);
  placeDesc.putEnumerated(charIDToTypeID("FTcs"), charIDToTypeID("QCSt"), charIDToTypeID("Qcsa"));
  executeAction(charIDToTypeID("Plc "), placeDesc, DialogModes.NO);
  var placed = doc.activeLayer;
  try { placed.rasterize(RasterizeType.ENTIRELAYER); } catch(e) {}
  placed.name = "제품이미지";
  if (productGroup) placed.move(productGroup, ElementPlacement.PLACEATBEGINNING);
  var abH = abLayer.bounds[3].as('px') - abLayer.bounds[1].as('px');
  var layerH = placed.bounds[3].as('px') - placed.bounds[1].as('px');
  if (layerH > 0) {
    var scale = (abH / layerH) * 100;
    placed.resize(scale, scale, AnchorPosition.MIDDLECENTER);
  }
}

// ── PSD로 저장 ────────────────────────────────────────
function saveAsPsd(doc, outPath) {
  var copy = doc.duplicate();
  var opts = new PhotoshopSaveOptions();
  opts.layers = true;
  opts.embedColorProfile = true;
  copy.saveAs(new File(outPath), opts, true);
  copy.close(SaveOptions.DONOTSAVECHANGES);
}

// ══════════════════════════════════════════════════════
//  메인 실행
// ══════════════════════════════════════════════════════
var doc = app.open(new File(CONFIG.psd));
var outFolder = new Folder(CONFIG.outputDir);
if (!outFolder.exists) outFolder.create();


// ── 아트보드: 600 ──────────────────────────────────────
var ab600 = findArtboard(doc, "600");
if (ab600) {
  setLogo(ab600.layers);
  setColors(ab600.layers);
}

// ── 아트보드: P ────────────────────────────────────────
var abP = findArtboard(doc, "P");
if (abP) {
  setLogo(abP.layers);
  setColors(abP.layers);
}

// ── 아트보드: SSF_01~03 (각 아트보드에 이미지 배치) ─────
var ssfMap = [
  { name: "SSF_01", img: CONFIG.imgSSF1, layer: "img_01" },
  { name: "SSF_02", img: CONFIG.imgSSF2, layer: "img_02" },
  { name: "SSF_03", img: CONFIG.imgSSF3, layer: "img_03" }
];

for (var si = 0; si < ssfMap.length; si++) {
  var abSSF = findArtboard(doc, ssfMap[si].name);
  if (!abSSF || !ssfMap[si].img || ssfMap[si].img === "") continue;

  // 기존 이미지 레이어 제거
  var oldSSF = findLayerByName(abSSF.layers, ssfMap[si].layer + "_img");
  if (oldSSF) oldSSF.remove();

  // 가이드 레이어 찾아서 크기 파악
  var guideLayer = findLayerByName(abSSF.layers, ssfMap[si].layer);
  var abBounds = abSSF.bounds;
  var abX = abBounds[0].as('px');
  var abY = abBounds[1].as('px');
  var abW = abBounds[2].as('px') - abX;
  var abH = abBounds[3].as('px') - abY;

  if (guideLayer) {
    var gb = guideLayer.bounds;
    var gW = gb[2].as('px') - gb[0].as('px');
    var gH = gb[3].as('px') - gb[1].as('px');
    if (gW > 0 && gH > 0) {
      abW = gW; abH = gH;
      abX = gb[0].as('px'); abY = gb[1].as('px');
    }
    guideLayer.visible = false;
  }

  // 이미지 Place
  doc.activeLayer = abSSF;
  var placeFileSSF = new File(ssfMap[si].img);
  var placeDescSSF = new ActionDescriptor();
  placeDescSSF.putPath(charIDToTypeID("null"), placeFileSSF);
  placeDescSSF.putEnumerated(charIDToTypeID("FTcs"), charIDToTypeID("QCSt"), charIDToTypeID("Qcsa"));
  executeAction(charIDToTypeID("Plc "), placeDescSSF, DialogModes.NO);
  var placedSSF = doc.activeLayer;
  try { placedSSF.rasterize(RasterizeType.ENTIRELAYER); } catch(e) {}
  placedSSF.name = ssfMap[si].layer + "_img";

  // 크기 맞춰 리사이징
  var pW = placedSSF.bounds[2].as('px') - placedSSF.bounds[0].as('px');
  var pH = placedSSF.bounds[3].as('px') - placedSSF.bounds[1].as('px');
  if (pW > 0 && pH > 0) {
    var scaleW = (abW / pW) * 100;
    var scaleH = (abH / pH) * 100;
    var scaleSSF = Math.max(scaleW, scaleH);
    placedSSF.resize(scaleSSF, scaleSSF, AnchorPosition.MIDDLECENTER);
  }

  // 아트보드 중앙으로 이동
  var pCX = (placedSSF.bounds[0].as('px') + placedSSF.bounds[2].as('px')) / 2;
  var pCY = (placedSSF.bounds[1].as('px') + placedSSF.bounds[3].as('px')) / 2;
  var aCX = abX + abW / 2;
  var aCY = abY + abH / 2;
  placedSSF.translate(aCX - pCX, aCY - pCY);
}


// ── img_smart 스마트 오브젝트 열어서 이미지 배치 (한 번만!) ──
if (CONFIG.imgCommon && CONFIG.imgCommon !== "") {
  var ab600tmp = findArtboard(doc, "600");
  var smartObj = ab600tmp ? findLayerByName(ab600tmp.layers, "img_smart") : null;

  if (smartObj) {
    doc.activeLayer = smartObj;

    // runMenuItem 방식으로 스마트 오브젝트 열기
    runMenuItem(stringIDToTypeID('placedLayerEditContents'));
    var smartDoc = app.activeDocument;

    // 내부의 img 레이어 찾기 (크기 기준)
    var imgGuide = findLayerByName(smartDoc.layers, "img");
    var iX = 0, iY = 0;
    var iW = smartDoc.width.as('px'), iH = smartDoc.height.as('px');
    if (imgGuide) {
      var ib = imgGuide.bounds;
      var bW = ib[2].as('px') - ib[0].as('px');
      var bH = ib[3].as('px') - ib[1].as('px');
      if (bW > 0 && bH > 0) {
        iX = ib[0].as('px'); iY = ib[1].as('px');
        iW = bW; iH = bH;
      }
      imgGuide.visible = false;
    }

    // 기존 배치이미지 제거
    var oldImg = findLayerByName(smartDoc.layers, "배치이미지");
    if (oldImg) oldImg.remove();

    // 이미지 Place
    var placeFileSmart = new File(CONFIG.imgCommon);
    var placeDescSmart = new ActionDescriptor();
    placeDescSmart.putPath(charIDToTypeID("null"), placeFileSmart);
    placeDescSmart.putEnumerated(charIDToTypeID("FTcs"), charIDToTypeID("QCSt"), charIDToTypeID("Qcsa"));
    executeAction(charIDToTypeID("Plc "), placeDescSmart, DialogModes.NO);
    var placedSmart = smartDoc.activeLayer;
    try { placedSmart.rasterize(RasterizeType.ENTIRELAYER); } catch(e) {}
    placedSmart.name = "배치이미지";

    // img 레이어 크기에 맞게 리사이징
    var pWs = placedSmart.bounds[2].as('px') - placedSmart.bounds[0].as('px');
    var pHs = placedSmart.bounds[3].as('px') - placedSmart.bounds[1].as('px');
    if (pWs > 0 && pHs > 0) {
      var scaleWs = (iW / pWs) * 100;
      var scaleHs = (iH / pHs) * 100;
      var scaleSmart = Math.max(scaleWs, scaleHs);
      placedSmart.resize(scaleSmart, scaleSmart, AnchorPosition.MIDDLECENTER);
    }

    // 중앙 정렬
    var pCXs = (placedSmart.bounds[0].as('px') + placedSmart.bounds[2].as('px')) / 2;
    var pCYs = (placedSmart.bounds[1].as('px') + placedSmart.bounds[3].as('px')) / 2;
    placedSmart.translate((iX + iW/2) - pCXs, (iY + iH/2) - pCYs);

    // 스마트 오브젝트 저장 (닫지 않고 열린 채로 유지)
    smartDoc.save();
    app.activeDocument = doc;
  }
}
// 모든 작업 완료 후 스마트 오브젝트 다시 열기
var ab600final = findArtboard(doc, "600");
var smartObjFinal = ab600final ? findLayerByName(ab600final.layers, "img_smart") : null;
if (smartObjFinal) {
  doc.activeLayer = smartObjFinal;
  runMenuItem(stringIDToTypeID('placedLayerEditContents'));
}

alert("✅ 완료!\\n저장 위치: " + CONFIG.outputDir + "/아트보드_작업.psd");
""" % {
        'psd': psd, 'img_600': img_600, 'img_p': img_p,
        'img_common': img_common,
        'img_ssf1': img_ssf1, 'img_ssf2': img_ssf2, 'img_ssf3': img_ssf3,
        'img_1200': img_1200, 'logo': logo, 'out_dir': out_dir,
        'color_map': color_map,
    }
    return jsx

def build_jsx_wconcept(config):
    def clean(p):
        return p.strip().strip('"').strip("'").replace('\\', '/')

    psd      = clean(config.get('psd', ''))
    img_600  = clean(config.get('img_600', ''))
    img_p    = clean(config.get('img_p', ''))
    img_common = clean(config.get('imgCommon', ''))
    img_ssf1 = clean(config.get('img_ssf1', ''))
    img_ssf2 = clean(config.get('img_ssf2', ''))
    img_ssf3 = clean(config.get('img_ssf3', ''))
    img_1200 = clean(config.get('img_1200', ''))
    logo     = config.get('logo', 'list_logo')
    out_dir  = clean(config.get('output_dir', 'C:/Output'))
    color_map = json.dumps(config.get('color_assignments', {}))

    jsx = """
// ═══════════════════════════════════════════════════════
//  포토샵 자동화 스크립트 — 아트보드 버전
// ═══════════════════════════════════════════════════════
#target photoshop

var CONFIG = {
  psd:      "%(psd)s",
  img600:   "%(img_600)s",
  imgP:     "%(img_p)s",
  imgCommon: "%(img_common)s",
  imgSSF1:  "%(img_ssf1)s",
  imgSSF2:  "%(img_ssf2)s",
  imgSSF3:  "%(img_ssf3)s",
  img1200:  "%(img_1200)s",
  logoName: "%(logo)s",
  outputDir:"%(out_dir)s",
  colorMap: %(color_map)s
};

// ── 유틸 ──────────────────────────────────────────────
function findLayerByName(layers, name) {
  for (var i = 0; i < layers.length; i++) {
    if (layers[i].name === name) return layers[i];
    if (layers[i].typename === 'LayerSet') {
      var found = findLayerByName(layers[i].layers, name);
      if (found) return found;
    }
  }
  return null;
}

function findGroup(layers, name) {
  for (var i = 0; i < layers.length; i++) {
    if (layers[i].name === name && layers[i].typename === 'LayerSet')
      return layers[i];
  }
  return null;
}

function findArtboard(doc, name) {
  for (var i = 0; i < doc.layers.length; i++) {
    if (doc.layers[i].name === name) return doc.layers[i];
  }
  return null;
}

// ── Color Overlay 적용 (Photoshop 27 호환) ────────────
function setColorOverlay(layer, r, g, b) {
  app.activeDocument.activeLayer = layer;
  var idsetd = charIDToTypeID("setd");
  var desc1 = new ActionDescriptor();
  var ref1 = new ActionReference();
  ref1.putEnumerated(charIDToTypeID("Lyr "), charIDToTypeID("Ordn"), charIDToTypeID("Trgt"));
  desc1.putReference(charIDToTypeID("null"), ref1);
  var desc2 = new ActionDescriptor();
  var desc3 = new ActionDescriptor();
  desc3.putBoolean(charIDToTypeID("enab"), true);
  desc3.putEnumerated(charIDToTypeID("Md  "), charIDToTypeID("BlnM"), charIDToTypeID("Nrml"));
  desc3.putUnitDouble(charIDToTypeID("Opct"), charIDToTypeID("#Prc"), 100.0);
  var desc4 = new ActionDescriptor();
  desc4.putDouble(charIDToTypeID("Rd  "), r);
  desc4.putDouble(charIDToTypeID("Grn "), g);
  desc4.putDouble(charIDToTypeID("Bl  "), b);
  desc3.putObject(charIDToTypeID("Clr "), charIDToTypeID("RGBC"), desc4);
  desc2.putObject(charIDToTypeID("SoFi"), charIDToTypeID("SoFi"), desc3);
  desc1.putObject(charIDToTypeID("T   "), charIDToTypeID("Lefx"), desc2);
  executeAction(idsetd, desc1, DialogModes.NO);
}

// ── 로고 설정 ─────────────────────────────────────────
function setLogo(abLayers) {
  var logoNames = {"list_logo":1,"sistina_logo":1,"shesmiss_logo":1};
  var logoGroup = findGroup(abLayers, "로고");
  if (!logoGroup) return;
  for (var i = 0; i < logoGroup.layers.length; i++) {
    var ll = logoGroup.layers[i];
    if (logoNames[ll.name]) {
      ll.visible = (ll.name === CONFIG.logoName);
    }
  }
}

// ── 컬러 설정 ─────────────────────────────────────────
function setColors(abLayers) {
  var colorGroup = findGroup(abLayers, "컬러링");
  if (!colorGroup) return;
  for (var i = 0; i < colorGroup.layers.length; i++) {
    colorGroup.layers[i].visible = false;
  }
  for (var layerNum in CONFIG.colorMap) {
    if (!CONFIG.colorMap.hasOwnProperty(layerNum)) continue;
    var hex = CONFIG.colorMap[layerNum].replace('#','');
    var r = parseInt(hex.substr(0,2),16);
    var g = parseInt(hex.substr(2,2),16);
    var b = parseInt(hex.substr(4,2),16);
    var layer = findLayerByName(colorGroup.layers, layerNum);
    if (!layer) continue;
    layer.visible = true;
    try { setColorOverlay(layer, r, g, b); } catch(e) {}
  }
}

// ── 이미지 배치 ───────────────────────────────────────
function placeImage(doc, abLayer, imgPath) {
  if (!imgPath || imgPath === "") return;
  var productGroup = findGroup(abLayer.layers, "제품컷");
  var old = findLayerByName(abLayer.layers, "제품이미지");
  if (old) old.remove();
  doc.activeLayer = abLayer;
  var placeFile = new File(imgPath);
  var placeDesc = new ActionDescriptor();
  placeDesc.putPath(charIDToTypeID("null"), placeFile);
  placeDesc.putEnumerated(charIDToTypeID("FTcs"), charIDToTypeID("QCSt"), charIDToTypeID("Qcsa"));
  executeAction(charIDToTypeID("Plc "), placeDesc, DialogModes.NO);
  var placed = doc.activeLayer;
  try { placed.rasterize(RasterizeType.ENTIRELAYER); } catch(e) {}
  placed.name = "제품이미지";
  if (productGroup) placed.move(productGroup, ElementPlacement.PLACEATBEGINNING);
  var abH = abLayer.bounds[3].as('px') - abLayer.bounds[1].as('px');
  var layerH = placed.bounds[3].as('px') - placed.bounds[1].as('px');
  if (layerH > 0) {
    var scale = (abH / layerH) * 100;
    placed.resize(scale, scale, AnchorPosition.MIDDLECENTER);
  }
}

// ── PSD로 저장 ────────────────────────────────────────
function saveAsPsd(doc, outPath) {
  var copy = doc.duplicate();
  var opts = new PhotoshopSaveOptions();
  opts.layers = true;
  opts.embedColorProfile = true;
  copy.saveAs(new File(outPath), opts, true);
  copy.close(SaveOptions.DONOTSAVECHANGES);
}

// ══════════════════════════════════════════════════════
//  메인 실행
// ══════════════════════════════════════════════════════
var doc = app.open(new File(CONFIG.psd));
var outFolder = new Folder(CONFIG.outputDir);
if (!outFolder.exists) outFolder.create();

// 600
var ab600 = findArtboard(doc, "600");
if (ab600) { setLogo(ab600.layers); setColors(ab600.layers); }

// P
var abP = findArtboard(doc, "P");
if (abP) { setLogo(abP.layers); setColors(abP.layers); }

// SSF_01~03
var ssfMap = [
  { name: "SSF_01", img: CONFIG.imgSSF1, layer: "img_01" },
  { name: "SSF_02", img: CONFIG.imgSSF2, layer: "img_02" },
  { name: "SSF_03", img: CONFIG.imgSSF3, layer: "img_03" }
];
for (var si = 0; si < ssfMap.length; si++) {
  var abSSF = findArtboard(doc, ssfMap[si].name);
  if (!abSSF || !ssfMap[si].img || ssfMap[si].img === "") continue;
  var oldSSF = findLayerByName(abSSF.layers, ssfMap[si].layer + "_img");
  if (oldSSF) oldSSF.remove();
  var guideLayer = findLayerByName(abSSF.layers, ssfMap[si].layer);
  var abBounds = abSSF.bounds;
  var abX = abBounds[0].as("px"), abY = abBounds[1].as("px");
  var abW = abBounds[2].as("px") - abX, abH = abBounds[3].as("px") - abY;
  if (guideLayer) {
    var gb = guideLayer.bounds;
    var gW = gb[2].as("px") - gb[0].as("px"), gH = gb[3].as("px") - gb[1].as("px");
    if (gW > 0 && gH > 0) { abW = gW; abH = gH; abX = gb[0].as("px"); abY = gb[1].as("px"); }
    guideLayer.visible = false;
  }
  doc.activeLayer = abSSF;
  var placeFileSSF = new File(ssfMap[si].img);
  var pdSSF = new ActionDescriptor();
  pdSSF.putPath(charIDToTypeID("null"), placeFileSSF);
  pdSSF.putEnumerated(charIDToTypeID("FTcs"), charIDToTypeID("QCSt"), charIDToTypeID("Qcsa"));
  executeAction(charIDToTypeID("Plc "), pdSSF, DialogModes.NO);
  var placedSSF = doc.activeLayer;
  try { placedSSF.rasterize(RasterizeType.ENTIRELAYER); } catch(e) {}
  placedSSF.name = ssfMap[si].layer + "_img";
  var pW = placedSSF.bounds[2].as("px") - placedSSF.bounds[0].as("px");
  var pH = placedSSF.bounds[3].as("px") - placedSSF.bounds[1].as("px");
  if (pW > 0 && pH > 0) {
    var scaleSSF = Math.max((abW/pW)*100, (abH/pH)*100);
    placedSSF.resize(scaleSSF, scaleSSF, AnchorPosition.MIDDLECENTER);
  }
  var pCX = (placedSSF.bounds[0].as("px") + placedSSF.bounds[2].as("px")) / 2;
  var pCY = (placedSSF.bounds[1].as("px") + placedSSF.bounds[3].as("px")) / 2;
  placedSSF.translate((abX + abW/2) - pCX, (abY + abH/2) - pCY);
}

// W_01~03
var wMap = [
  { name: "W_01", img: CONFIG.imgSSF1, layer: "img_04" },
  { name: "W_02", img: CONFIG.imgSSF2, layer: "img_05" },
  { name: "W_03", img: CONFIG.imgSSF3, layer: "img_06" }
];
for (var wi = 0; wi < wMap.length; wi++) {
  var abW = findArtboard(doc, wMap[wi].name);
  if (!abW || !wMap[wi].img || wMap[wi].img === "") continue;
  var oldW = findLayerByName(abW.layers, wMap[wi].layer + "_img");
  if (oldW) oldW.remove();
  var guideW = findLayerByName(abW.layers, wMap[wi].layer);
  var wBounds = abW.bounds;
  var wX = wBounds[0].as("px"), wY = wBounds[1].as("px");
  var wW = wBounds[2].as("px") - wX, wH = wBounds[3].as("px") - wY;
  if (guideW) {
    var gwb = guideW.bounds;
    var gwW = gwb[2].as("px") - gwb[0].as("px"), gwH = gwb[3].as("px") - gwb[1].as("px");
    if (gwW > 0 && gwH > 0) { wW = gwW; wH = gwH; wX = gwb[0].as("px"); wY = gwb[1].as("px"); }
    guideW.visible = false;
  }
  doc.activeLayer = abW;
  var placeFileW = new File(wMap[wi].img);
  var pdW = new ActionDescriptor();
  pdW.putPath(charIDToTypeID("null"), placeFileW);
  pdW.putEnumerated(charIDToTypeID("FTcs"), charIDToTypeID("QCSt"), charIDToTypeID("Qcsa"));
  executeAction(charIDToTypeID("Plc "), pdW, DialogModes.NO);
  var placedW = doc.activeLayer;
  try { placedW.rasterize(RasterizeType.ENTIRELAYER); } catch(e) {}
  placedW.name = wMap[wi].layer + "_img";
  var pwW = placedW.bounds[2].as("px") - placedW.bounds[0].as("px");
  var phW = placedW.bounds[3].as("px") - placedW.bounds[1].as("px");
  if (pwW > 0 && phW > 0) {
    placedW.resize(Math.max((wW/pwW)*100,(wH/phW)*100), Math.max((wW/pwW)*100,(wH/phW)*100), AnchorPosition.MIDDLECENTER);
  }
  var pCXW = (placedW.bounds[0].as("px") + placedW.bounds[2].as("px")) / 2;
  var pCYW = (placedW.bounds[1].as("px") + placedW.bounds[3].as("px")) / 2;
  placedW.translate((wX + wW/2) - pCXW, (wY + wH/2) - pCYW);
}

// Smart Object
if (CONFIG.imgCommon && CONFIG.imgCommon !== "") {
  var ab600tmp = findArtboard(doc, "600");
  var smartObj = ab600tmp ? findLayerByName(ab600tmp.layers, "img_smart") : null;
  if (smartObj) {
    doc.activeLayer = smartObj;
    runMenuItem(stringIDToTypeID("placedLayerEditContents"));
    var smartDoc = app.activeDocument;
    var imgGuide = findLayerByName(smartDoc.layers, "img");
    var iX = 0, iY = 0, iW = smartDoc.width.as("px"), iH = smartDoc.height.as("px");
    if (imgGuide) {
      var ib = imgGuide.bounds;
      var bW = ib[2].as("px") - ib[0].as("px"), bH = ib[3].as("px") - ib[1].as("px");
      if (bW > 0 && bH > 0) { iX = ib[0].as("px"); iY = ib[1].as("px"); iW = bW; iH = bH; }
      imgGuide.visible = false;
    }
    var oldImg = findLayerByName(smartDoc.layers, "placed_img");
    if (oldImg) oldImg.remove();
    var pfs = new File(CONFIG.imgCommon);
    var pds = new ActionDescriptor();
    pds.putPath(charIDToTypeID("null"), pfs);
    pds.putEnumerated(charIDToTypeID("FTcs"), charIDToTypeID("QCSt"), charIDToTypeID("Qcsa"));
    executeAction(charIDToTypeID("Plc "), pds, DialogModes.NO);
    var placedSmart = smartDoc.activeLayer;
    try { placedSmart.rasterize(RasterizeType.ENTIRELAYER); } catch(e) {}
    placedSmart.name = "placed_img";
    var pWs = placedSmart.bounds[2].as("px") - placedSmart.bounds[0].as("px");
    var pHs = placedSmart.bounds[3].as("px") - placedSmart.bounds[1].as("px");
    if (pWs > 0 && pHs > 0) {
      var scaleSmart = Math.max((iW/pWs)*100, (iH/pHs)*100);
      placedSmart.resize(scaleSmart, scaleSmart, AnchorPosition.MIDDLECENTER);
    }
    var pCXs = (placedSmart.bounds[0].as("px") + placedSmart.bounds[2].as("px")) / 2;
    var pCYs = (placedSmart.bounds[1].as("px") + placedSmart.bounds[3].as("px")) / 2;
    placedSmart.translate((iX + iW/2) - pCXs, (iY + iH/2) - pCYs);
    smartDoc.save();
  }
}

alert("Done!");
""" % {
        'psd': psd, 'img_600': img_600, 'img_p': img_p,
        'img_common': img_common,
        'img_ssf1': img_ssf1, 'img_ssf2': img_ssf2, 'img_ssf3': img_ssf3,
        'img_1200': img_1200, 'logo': logo, 'out_dir': out_dir,
        'color_map': color_map,
    }
    return jsx

HTML_PAGE = '<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>IDF STUDIO · 썸네일 리사이징</title><style>*{box-sizing:border-box}body{margin:0;background:#f6f8f9;color:#202a30;font:14px/1.5 Arial,\'Malgun Gothic\',sans-serif}header{height:68px;background:white;border-bottom:1px solid #e0e6e8;display:flex;justify-content:space-between;align-items:center;padding:14px 28px}.brand{display:flex;align-items:center;gap:12px}.mark{width:34px;height:34px;padding:6px;border:1px solid #c4e5dc;border-radius:9px;background:#e9f6f2;color:#087f70}.word{font-size:13px;letter-spacing:.09em;font-weight:600}.divider{width:1px;height:16px;background:#ccd7db}h1{font-size:15px;font-weight:600;letter-spacing:-.3px;margin:0}button{font:inherit;cursor:pointer;border:1px solid #ccd7db;border-radius:8px;background:white;color:#4f6069;padding:8px 13px}.top{max-width:960px;padding:26px 24px 0;margin:auto}.tabs{display:flex;gap:6px;background:white;padding:5px;border:1px solid #ccd7db;border-radius:10px}.tabs button{flex:1;border:0;font-weight:600;padding:12px}.tabs button[aria-selected=true]{background:#087f70;color:white}.tabs button[data-version=wconcept][aria-selected=true]{background:#167d85}.note{font-size:12px;color:#65747c;margin:16px 0 22px}iframe{display:block;width:100%;height:calc(100vh - 215px);min-height:420px;border:0}iframe[hidden]{display:none}:focus-visible{outline:2px solid #087f70;outline-offset:2px}@media(max-width:600px){header{height:auto;padding:12px 16px;gap:12px;flex-wrap:wrap}.brand{gap:8px}.word{font-size:11px}h1{font-size:14px}.top{padding:18px 16px 0}}</style></head><body><header><div class="brand"><span class="mark"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="4" y="4" width="12" height="16" rx="2"/><path d="M19 7h2v13h-2M4 15l4-4 8 7"/><circle cx="12" cy="8" r="1"/></svg></span><span class="word">IDF STUDIO</span><span class="divider"></span><h1>썸네일 리사이징</h1></div><button id="reset">새 작업</button></header><div class="top"><div class="tabs" role="tablist" aria-label="리사이징 버전"><button id="tab-standard" data-version="standard" role="tab" aria-controls="standard" aria-selected="true">기존 버전</button><button id="tab-wconcept" data-version="wconcept" role="tab" aria-controls="wconcept" aria-selected="false" tabindex="-1">W컨셉 포함 버전</button></div><p class="note">PSD 가이드 경로와 출력 폴더는 버전별로 기억합니다. 생성한 JSX는 입력한 폴더에 바로 저장됩니다.</p></div><iframe id="standard" src="/standard" title="기존 버전" role="tabpanel" aria-labelledby="tab-standard"></iframe><iframe id="wconcept" src="/wconcept" title="W컨셉 포함 버전" role="tabpanel" aria-labelledby="tab-wconcept" hidden></iframe><script>let active=\'standard\';function choose(v){active=v;document.querySelectorAll(\'[data-version]\').forEach(b=>{const on=b.dataset.version===v;b.setAttribute(\'aria-selected\',String(on));b.tabIndex=on?0:-1});[\'standard\',\'wconcept\'].forEach(k=>document.getElementById(k).hidden=k!==v);try{localStorage.setItem(\'idf-resize-active\',v)}catch(e){}}document.querySelectorAll(\'[data-version]\').forEach(b=>{b.onclick=()=>choose(b.dataset.version);b.onkeydown=e=>{if([\'ArrowLeft\',\'ArrowRight\',\'Home\',\'End\'].includes(e.key)){e.preventDefault();choose(e.key===\'Home\'?\'standard\':e.key===\'End\'?\'wconcept\':active===\'standard\'?\'wconcept\':\'standard\');document.querySelector(\'[data-version=\'+active+\']\').focus()}}});document.getElementById(\'reset\').onclick=()=>{const w=document.getElementById(active).contentWindow;if(typeof w.resetAll===\'function\')w.resetAll()};try{if(localStorage.getItem(\'idf-resize-active\')===\'wconcept\')choose(\'wconcept\')}catch(e){}</script></body></html>'
STANDARD_PAGE = '<!DOCTYPE html>\n<html lang="ko">\n<head>\n<meta charset="UTF-8">\n<meta name="viewport" content="width=device-width, initial-scale=1.0">\n<title>기존 버전</title>\n\n<style>\n:root {\n  --bg:#0e0e10; --s1:#161618; --s2:#1e1e21; --s3:#26262a;\n  --border:rgba(255,255,255,0.07); --border2:rgba(255,255,255,0.13);\n  --text:#f0f0f2; --muted:#6e6e78; --muted2:#9898a4;\n  --accent:#4ec9b0; --accent2:#6ddfc8;\n  --success:#4ecb8d; --danger:#f07070; --r:12px; --r-sm:8px;\n}\n*{box-sizing:border-box;margin:0;padding:0;}\nbody{background:var(--bg);color:var(--text);font-family:\'DM Sans\',sans-serif;font-size:14px;min-height:100vh;}\n.app-header{\n  position:sticky;top:0;z-index:100;\n  background:rgba(14,14,16,0.85);backdrop-filter:blur(20px);\n  border-bottom:1px solid var(--border);\n  padding:14px 24px;display:flex;align-items:center;justify-content:space-between;\n}\n.app-title{font-size:15px;font-weight:600;letter-spacing:-.3px;display:flex;align-items:center;gap:8px;}\n.app-title span{color:var(--accent);}\n.ab-badge{font-size:10px;background:rgba(78,201,176,0.15);color:var(--accent);border-radius:4px;padding:2px 8px;font-weight:500;}\n.main{max-width:860px;margin:0 auto;padding:28px 20px 60px;}\n.step{margin-bottom:12px;border-radius:var(--r);border:1px solid var(--border);overflow:hidden;transition:border-color .2s;}\n.step:focus-within{border-color:var(--border2);}\n.step-header{display:flex;align-items:center;gap:12px;padding:14px 18px;background:var(--s1);cursor:pointer;user-select:none;}\n.step-num{width:24px;height:24px;border-radius:50%;background:var(--s3);color:var(--muted2);font-size:11px;font-weight:600;display:flex;align-items:center;justify-content:center;flex-shrink:0;}\n.step.active .step-num{background:var(--accent);color:#000;}\n.step-title{font-size:13px;font-weight:500;flex:1;}\n.step-badge{font-size:11px;color:var(--muted);background:var(--s3);padding:2px 8px;border-radius:20px;}\n.step-body{padding:18px;background:var(--s2);border-top:1px solid var(--border);}\ninput[type=text],input[type=url]{width:100%;background:var(--s3);border:1px solid var(--border);border-radius:var(--r-sm);color:var(--text);font-family:\'DM Sans\',sans-serif;font-size:13px;padding:10px 14px;outline:none;transition:border-color .2s;}\ninput:focus{border-color:rgba(78,201,176,0.5);}\ninput::placeholder{color:var(--muted);}\n.btn{background:var(--accent);border:none;border-radius:var(--r-sm);color:#000;cursor:pointer;font-family:\'DM Sans\',sans-serif;font-size:13px;font-weight:600;padding:10px 20px;transition:background .15s,transform .1s;white-space:nowrap;}\n.btn:hover{background:var(--accent2);}\n.btn:active{transform:scale(.97);}\n.btn-ghost{background:transparent;border:1px solid var(--border2);color:var(--muted2);font-weight:400;}\n.btn-ghost:hover{background:var(--s3);color:var(--text);}\n.btn-danger{background:transparent;border:1px solid rgba(240,112,112,0.3);color:var(--danger);font-weight:400;}\n.btn-danger:hover{background:rgba(240,112,112,0.08);}\n.btn-sm{padding:7px 14px;font-size:12px;}\n.btn-full{width:100%;padding:15px;font-size:15px;border-radius:var(--r);}\n.color-grid{display:flex;flex-wrap:wrap;gap:10px;margin-top:14px;padding-bottom:24px;}\n.color-chip{width:40px;height:40px;border-radius:var(--r-sm);cursor:pointer;border:2px solid transparent;transition:transform .15s,border-color .15s;position:relative;flex-shrink:0;}\n.color-chip:hover{transform:scale(1.1);}\n.color-chip.selected{border-color:#6ddfc8;transform:scale(1.08);}\n.color-chip .check{position:absolute;top:3px;right:3px;width:18px;height:18px;background:rgba(0,80,60,0.85);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:800;color:#fff !important;opacity:0;transition:opacity .15s;line-height:1;}\n.color-chip.selected .check{opacity:1;}\n.chip-label{position:absolute;bottom:-20px;left:50%;transform:translateX(-50%);font-size:9px;white-space:nowrap;color:var(--muted);font-family:\'DM Mono\',monospace;pointer-events:none;}\n.assign-list{display:flex;flex-direction:column;gap:6px;}\n.assign-row{display:flex;align-items:center;gap:10px;background:var(--s3);border-radius:var(--r-sm);padding:8px 12px;border:1px solid var(--border);}\n.assign-preview{width:32px;height:32px;border-radius:6px;flex-shrink:0;cursor:pointer;border:1px solid rgba(255,255,255,0.1);}\n.assign-name{font-size:12px;font-family:\'DM Mono\',monospace;color:var(--muted2);min-width:90px;}\n.slot-select{background:var(--s2);border:1px solid var(--border);border-radius:6px;color:var(--text);font-family:\'DM Sans\',sans-serif;font-size:12px;padding:5px 10px;outline:none;}\n.logo-group{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;}\n.logo-btn{background:var(--s3);border:1px solid var(--border);border-radius:var(--r-sm);color:var(--muted2);font-family:\'DM Sans\',sans-serif;font-size:12px;font-weight:500;padding:12px;cursor:pointer;text-align:center;transition:all .2s;}\n.logo-btn.active{background:rgba(78,201,176,0.1);border-color:var(--accent);color:var(--accent);font-weight:600;}\n.ab-block{background:var(--s3);border:1px solid var(--border);border-radius:var(--r-sm);padding:14px;margin-bottom:10px;}\n.ab-block:last-child{margin-bottom:0;}\n.ab-block-title{font-size:11px;font-weight:600;letter-spacing:.5px;text-transform:uppercase;color:var(--accent);margin-bottom:10px;display:flex;align-items:center;gap:6px;}\n.ab-block-title .badge{background:rgba(78,201,176,0.1);color:var(--accent);border-radius:4px;font-size:10px;padding:1px 6px;}\n.field-label{font-size:11px;color:var(--muted);margin-bottom:5px;font-weight:500;}\n.saved-badge{display:inline-flex;align-items:center;gap:4px;font-size:10px;color:var(--success);margin-left:6px;}\n.two-col{display:grid;grid-template-columns:1fr 1fr;gap:8px;}\n.status{background:var(--s3);border-radius:var(--r-sm);font-size:12px;padding:12px 16px;color:var(--muted);min-height:42px;line-height:1.6;border:1px solid var(--border);margin-top:10px;}\n.status.ok{color:var(--success);border-color:rgba(78,203,141,0.2);}\n.status.err{color:var(--danger);border-color:rgba(240,112,112,0.2);}\n.hint{font-size:11px;color:var(--muted);margin-bottom:12px;line-height:1.6;}\n.hint b{color:var(--muted2);}\n.img-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:10px;}\n.img-slot{border:2px dashed rgba(78,201,176,0.2);border-radius:var(--r-sm);padding:6px;text-align:center;background:var(--s3);cursor:pointer;position:relative;transition:border-color .15s,transform .1s;}\n.img-slot:hover{border-color:rgba(78,201,176,0.5);transform:scale(1.02);}\n.img-slot.sel-1{border:2px solid #4ec9b0;box-shadow:0 0 0 2px rgba(78,201,176,0.25);}\n.img-slot.sel-2{border:2px solid #6ddfc8;box-shadow:0 0 0 2px rgba(109,223,200,0.25);}\n.img-slot.sel-3{border:2px solid #9eeee0;box-shadow:0 0 0 2px rgba(158,238,224,0.25);}\n.img-slot img{width:100%;height:70px;object-fit:cover;border-radius:4px;display:block;}\n.img-slot-badge{position:absolute;top:5px;left:5px;background:#4ec9b0;color:#000;font-size:10px;font-weight:700;border-radius:3px;padding:1px 6px;display:none;}\n.img-slot.sel-1 .img-slot-badge,.img-slot.sel-2 .img-slot-badge,.img-slot.sel-3 .img-slot-badge{display:block;}\n.img-slot-name{font-size:9px;color:var(--muted);margin-top:4px;word-break:break-all;line-height:1.3;}\n.img-hint{font-size:11px;color:var(--muted2);margin-top:8px;padding:7px 12px;background:var(--s3);border-radius:var(--r-sm);border:1px solid var(--border);}\n.img-hint b{color:var(--accent);}\n</style>\n<style>\n:root{--bg:#f6f8f9;--s1:#f7f9fa;--s2:#fff;--s3:#f1f5f6;--border:#e0e6e8;--border2:#ccd7db;--text:#202a30;--muted:#65747c;--muted2:#4f6069;--accent:#087f70;--accent2:#066c5f;--success:#087f70;--danger:#bb3c4a;color-scheme:light}\nbody{background:var(--bg);color:var(--text);font:14px/1.6 Arial,\'Malgun Gothic\',sans-serif}button,input,select{font-family:inherit!important}.main{max-width:960px;padding:0 24px 50px;margin:0 auto}.step-title{font-size:14px;font-weight:600}.hint,.field-label,.ab-block-title,.step-badge,.saved-badge,.chip-label,.img-slot-name{font-size:12px}.btn,input[type=text],input[type=url],.logo-btn,.slot-select{font-size:14px}.btn{background:var(--accent);color:white}.btn:hover{background:var(--accent2)}.btn-ghost{background:transparent;color:var(--muted2);border-color:var(--border2)}.btn-ghost:hover{background:var(--s3);color:var(--text)}.logo-btn.active{background:#eaf7f3;border-color:var(--accent);color:var(--accent)}.step.active .step-num{background:var(--accent);color:white}.step-body{background:#fff}.step-header{background:var(--s1)}input::placeholder{color:#75838b}.status{color:var(--muted2)}:focus-visible{outline:2px solid var(--accent);outline-offset:2px}@media(max-width:560px){.main{padding:0 16px 36px}.two-col{grid-template-columns:1fr}}</style></head>\n<body>\n\n\n<main class="main">\n\n<!-- STEP 1 -->\n<div class="step active" id="step1">\n  <div class="step-header" onclick="toggleStep(\'step1\')">\n    <div class="step-num">1</div>\n    <div class="step-title">상세페이지 URL & 색상 추출</div>\n  </div>\n  <div class="step-body">\n    <div class="hint">idfmall 상품 URL을 붙여넣으면 <b>색상과 이미지를 동시에</b> 가져와요.</div>\n    <div style="display:flex;gap:8px">\n      <input type="url" id="url-input" placeholder="https://idfmall.co.kr/product/detail.html?..." style="flex:1">\n      <button class="btn" onclick="fetchAll()" id="extract-btn">✦ 추출</button>\n    </div>\n    <div id="color-status" class="status">URL을 입력하고 추출 버튼을 누르세요</div>\n    <div id="img-section" style="display:none;margin-top:12px">\n      <div style="font-size:11px;font-weight:700;letter-spacing:.5px;text-transform:uppercase;color:var(--accent);margin-bottom:6px;display:flex;align-items:center;gap:6px;">\n        🖼 추출된 이미지 <span id="img-badge" style="background:rgba(78,201,176,0.12);color:var(--accent2);border-radius:4px;font-size:10px;padding:1px 6px;"></span>\n        <span style="font-size:10px;color:var(--muted);font-weight:400;">클릭 순서대로 공통→SSF2→SSF3 입력</span>\n      </div>\n      <div class="img-grid" id="img-grid"></div>\n      <div class="img-hint" id="img-hint"><b>1번째</b> 클릭 → 공통 이미지 &nbsp;·&nbsp; <b>2번째</b> → SSF_02 &nbsp;·&nbsp; <b>3번째</b> → SSF_03</div>\n    </div>\n    <div id="color-all-btn" style="display:none;margin-top:8px">\n      <button class="btn btn-sm btn-ghost" onclick="selectAllColors()" style="width:100%">✦ 전체 선택</button>\n    </div>\n    <div id="color-grid" class="color-grid"></div>\n  </div>\n</div>\n\n<!-- STEP 2 -->\n<div class="step" id="step2" style="display:none">\n  <div class="step-header" onclick="toggleStep(\'step2\')">\n    <div class="step-num">2</div>\n    <div class="step-title">컬러 → 레이어 배치</div>\n    <div class="step-badge" id="color-count-badge">0개 선택</div>\n  </div>\n  <div class="step-body">\n    <div class="hint">색상 칩을 클릭하면 <b>1번부터 자동 배정</b>돼요.</div>\n    <div class="assign-list" id="assign-list"></div>\n    <div style="margin-top:10px;display:flex;align-items:center;gap:8px">\n      <input type="color" id="inline-color-picker" value="#000000" style="width:40px;height:36px;border:1px solid var(--border2);border-radius:var(--r-sm);background:var(--s3);cursor:pointer;padding:2px;">\n      <button class="btn btn-sm btn-ghost" onclick="addColorFromPicker()">+ 추가하기</button>\n      <input type="color" id="hidden-color-input" style="position:absolute;opacity:0;pointer-events:none;width:0;height:0">\n    </div>\n  </div>\n</div>\n\n<!-- STEP 3 -->\n<div class="step" id="step3">\n  <div class="step-header" onclick="toggleStep(\'step3\')">\n    <div class="step-num">3</div>\n    <div class="step-title">로고 선택</div>\n    <div class="step-badge" id="logo-badge">LIST</div>\n  </div>\n  <div class="step-body">\n    <div class="logo-group">\n      <button class="logo-btn active" id="logo-list_logo" onclick="selectLogo(\'list_logo\')">LIST</button>\n      <button class="logo-btn" id="logo-sistina_logo" onclick="selectLogo(\'sistina_logo\')">SISTINA</button>\n      <button class="logo-btn" id="logo-shesmiss_logo" onclick="selectLogo(\'shesmiss_logo\')">SHESMISS</button>\n    </div>\n  </div>\n</div>\n\n<!-- STEP 4 -->\n<div class="step" id="step4">\n  <div class="step-header" onclick="toggleStep(\'step4\')">\n    <div class="step-num">4</div>\n    <div class="step-title">아트보드 PSD & 이미지 경로</div>\n    <div class="step-badge">경로 자동 저장</div>\n  </div>\n  <div class="step-body">\n    <div class="hint"><b>PSD 경로</b>는 자동 저장돼요. 이미지만 바꿔서 반복 작업 가능!<br>이미지는 <b>로컬 경로</b> 또는 <b>URL</b>(우클릭 → 이미지 주소 복사) 모두 가능해요.</div>\n\n    <div class="ab-block">\n      <div class="ab-block-title">📄 아트보드 PSD <span class="badge">1개 파일에 6개 아트보드</span></div>\n      <div class="field-label">PSD 경로 <span class="saved-badge" id="saved-psd" style="display:none">✓ 저장됨</span></div>\n      <input type="text" id="psd" placeholder="아트보드_템플릿.psd 경로" oninput="savePsdPath(\'psd\',this.value)">\n    </div>\n\n    <div style="background:rgba(78,201,176,0.07);border:1.5px solid rgba(78,201,176,0.35);border-radius:var(--r-sm);padding:14px;margin-bottom:10px;">\n      <div style="font-size:11px;font-weight:700;letter-spacing:.8px;text-transform:uppercase;color:var(--accent);margin-bottom:4px;display:flex;align-items:center;gap:6px;">\n        🖼 공통 이미지\n        <span style="background:rgba(78,201,176,0.15);color:var(--accent);border-radius:4px;font-size:10px;padding:1px 7px;font-weight:500;">600 · P · SSF_01 · 1200 동일 적용</span>\n      </div>\n      <div style="font-size:11px;color:var(--muted);margin-bottom:8px;">이미지 하나로 4개 아트보드에 자동으로 들어가요</div>\n      <input type="text" id="img_common" placeholder="경로 또는 https://..." style="border-color:rgba(78,201,176,0.25);">\n    </div>\n\n    <div class="ab-block">\n      <div class="ab-block-title">🖼 SSF_02 / SSF_03 <span class="badge">1500×2000 · 별도 이미지</span></div>\n      <div style="display:flex;flex-direction:column;gap:6px">\n        <div>\n          <div class="field-label">SSF_02 이미지</div>\n          <input type="text" id="img_ssf2" placeholder="경로 또는 https://...">\n        </div>\n        <div>\n          <div class="field-label">SSF_03 이미지</div>\n          <input type="text" id="img_ssf3" placeholder="경로 또는 https://...">\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n\n<!-- STEP 5 -->\n<div class="step" id="step5">\n  <div class="step-header" onclick="toggleStep(\'step5\')">\n    <div class="step-num">5</div>\n    <div class="step-title">출력 폴더</div>\n    <div class="step-badge" id="saved-output-badge" style="display:none">저장됨</div>\n  </div>\n  <div class="step-body">\n    <div class="hint">완성된 PSD가 저장될 폴더예요.</div>\n    <input type="text" id="output-dir" placeholder="C:\\Users\\...\\Output" oninput="saveOutputDir(this.value)">\n  </div>\n</div>\n\n<div style="height:16px"></div>\n<button class="btn btn-full" onclick="generateJSX()">🚀 JSX 스크립트 생성</button>\n<div id="gen-status" class="status">설정 완료 후 버튼을 누르세요</div>\n\n</main>\n\n<script>\nvar selectedColors = {};\nvar selectedLogo = \'list_logo\';\n\nfunction savePsdPath(key, val) {\n  try { localStorage.setItem(\'idf_resize_standard_\' + key, val); } catch(e) {}\n  var badge = document.getElementById(\'saved-\' + key);\n  if (badge) badge.style.display = val ? \'inline-flex\' : \'none\';\n}\nfunction saveOutputDir(val) {\n  try { localStorage.setItem(\'idf_resize_standard_output\', val); } catch(e) {}\n  var badge = document.getElementById(\'saved-output-badge\');\n  if (badge) badge.style.display = val ? \'inline\' : \'none\';\n}\nfunction loadSaved() {\n  try {\n    var savedLogo = localStorage.getItem(\'idf_resize_standard_logo\');\n    if (savedLogo) selectLogo(savedLogo);\n  } catch(e) {}\n  try {\n    var psd = localStorage.getItem(\'idf_resize_standard_psd\');\n    if (psd) { document.getElementById(\'psd\').value = psd; document.getElementById(\'saved-psd\').style.display = \'inline-flex\'; }\n    var out = localStorage.getItem(\'idf_resize_standard_output\');\n    if (out) { document.getElementById(\'output-dir\').value = out; document.getElementById(\'saved-output-badge\').style.display = \'inline\'; }\n  } catch(e) {}\n}\nfunction toggleStep(id) {\n  var body = document.querySelector(\'#\' + id + \' .step-body\');\n  if (body) body.style.display = body.style.display === \'none\' ? \'\' : \'none\';\n}\nfunction fetchAll() {\n  var url = document.getElementById(\'url-input\').value.trim();\n  if (!url) { setStatus(\'color-status\',\'URL을 입력하세요\',\'err\'); return; }\n  var btn = document.getElementById(\'extract-btn\');\n  btn.disabled = true; btn.textContent = \'추출 중...\';\n  setStatus(\'color-status\',\'색상과 이미지를 가져오는 중...\',\'\');\n  var cd = false, id = false, cr = null, ir = null;\n  function done() {\n    if (!cd || !id) return;\n    btn.disabled = false; btn.textContent = \'✦ 추출\';\n    if (cr && !cr.error) {\n      renderColorGrid(cr.colors);\n      document.getElementById(\'color-all-btn\').style.display = \'\';\n      var s2 = document.getElementById(\'step2\');\n      s2.style.display = \'\';\n      s2.querySelector(\'.step-body\').style.display = \'none\';\n    }\n    if (ir && ir.ok && ir.images.length > 0) renderImgSlots(ir.images);\n    var cc = cr && !cr.error ? cr.colors.length : 0;\n    var ic = ir && ir.ok ? ir.images.length : 0;\n    setStatus(\'color-status\', (cc||ic) ? \'✅ 색상 \'+cc+\'개 · 이미지 \'+ic+\'개 추출 완료\' : \'추출된 항목이 없어요\', (cc||ic)?\'ok\':\'err\');\n  }\n  fetch(\'/extract?url=\'+encodeURIComponent(url)).then(function(r){return r.json();}).then(function(d){cr=d;cd=true;done();}).catch(function(){cr={error:\'실패\',colors:[]};cd=true;done();});\n  fetch(\'/extract_images?url=\'+encodeURIComponent(url)).then(function(r){return r.json();}).then(function(d){ir=d;id=true;done();}).catch(function(){ir={ok:false,images:[]};id=true;done();});\n}\n\nvar imgSel = [];\nvar SLOTS = [\'img_common\',\'img_ssf2\',\'img_ssf3\'];\nvar SNAMES = [\'공통\',\'SSF2\',\'SSF3\'];\n\nfunction renderImgSlots(images) {\n  var grid = document.getElementById(\'img-grid\');\n  var sec = document.getElementById(\'img-section\');\n  document.getElementById(\'img-badge\').textContent = images.length+\'개\';\n  grid.innerHTML = \'\'; imgSel = []; sec.style.display = \'\';\n  images.forEach(function(url) {\n    var slot = document.createElement(\'div\');\n    slot.className = \'img-slot\';\n    var badge = document.createElement(\'div\'); badge.className = \'img-slot-badge\'; slot.appendChild(badge);\n    var img = document.createElement(\'img\');\n    img.src = url;\n    img.referrerPolicy = \'no-referrer\';\n    img.onerror = function(){\n      if (img.src !== \'/proxy?url=\'+encodeURIComponent(url)) {\n        img.src = \'/proxy?url=\'+encodeURIComponent(url);\n      } else {\n        img.style.display=\'none\';\n        var ph=document.createElement(\'div\');\n        ph.style.cssText=\'height:70px;display:flex;align-items:center;justify-content:center;font-size:10px;color:var(--muted);\';\n        ph.textContent=\'미리보기 불가\';\n        slot.insertBefore(ph, nm);\n      }\n    };\n    slot.appendChild(img);\n    var nm = document.createElement(\'div\'); nm.className = \'img-slot-name\'; nm.textContent = url.split(\'/\').pop(); slot.appendChild(nm);\n    slot.onclick = function(){ toggleImg(slot, url); };\n    grid.appendChild(slot);\n  });\n}\nfunction toggleImg(slot, url) {\n  var idx = imgSel.findIndex(function(x){return x.slot===slot;});\n  if (idx !== -1) { imgSel.splice(idx,1); }\n  else {\n    if (imgSel.length >= 3) { imgSel.shift(); }\n    imgSel.push({slot:slot, url:url});\n  }\n  document.querySelectorAll(\'.img-slot\').forEach(function(s){ s.className=\'img-slot\'; s.querySelector(\'.img-slot-badge\').textContent=\'\'; });\n  imgSel.forEach(function(x,i){\n    x.slot.className=\'img-slot sel-\'+(i+1);\n    x.slot.querySelector(\'.img-slot-badge\').textContent=(i+1)+\'·\'+SNAMES[i];\n  });\n  SLOTS.forEach(function(id){document.getElementById(id).value=\'\';});\n  imgSel.forEach(function(x,i){document.getElementById(SLOTS[i]).value=x.url;});\n  var hint = document.getElementById(\'img-hint\');\n  if (imgSel.length < 3) hint.innerHTML=\'선택 \'+imgSel.length+\'/3 — <b>\'+(imgSel.length+1)+\'번째</b> 클릭 → \'+SNAMES[imgSel.length];\n  else hint.innerHTML=\'✅ 3개 선택 완료! STEP 4에 자동 입력됐어요.\';\n}\nvar colorOrder = [];\n\nfunction makeChip(hex, name) {\n  var chip = document.createElement(\'div\');\n  chip.className = \'color-chip\';\n  chip.style.background = hex;\n  chip.title = name + \' \' + hex;\n  chip.setAttribute(\'data-hex\', hex);\n  chip.setAttribute(\'data-name\', name);\n  var label = document.createElement(\'div\'); label.className = \'chip-label\'; label.textContent = name; chip.appendChild(label);\n  var num = document.createElement(\'span\'); num.className = \'check\'; chip.appendChild(num);\n  chip.onclick = function(){ toggleColor(hex, name); };\n  return chip;\n}\nfunction renderColorGrid(colors) {\n  var grid = document.getElementById(\'color-grid\');\n  grid.innerHTML = \'\'; colorOrder = []; selectedColors = {};\n  var BLACK = \'#1A1A1A\', WHITE = \'#FFFFFF\';\n  grid.appendChild(makeChip(BLACK, \'Black\'));\n  colors.forEach(function(item) {\n    var h = item.hex.toUpperCase();\n    if (h === BLACK || h === WHITE) return;\n    grid.appendChild(makeChip(item.hex, item.name));\n  });\n  grid.appendChild(makeChip(WHITE, \'White\'));\n}\nfunction isDark(hex) {\n  var r=parseInt(hex.slice(1,3),16),g=parseInt(hex.slice(3,5),16),b=parseInt(hex.slice(5,7),16);\n  return (r*299+g*587+b*114)/1000 < 128;\n}\nfunction toggleColor(hex, name) {\n  var idx = colorOrder.findIndex(function(x){return x.hex===hex;});\n  if (idx !== -1) { colorOrder.splice(idx,1); delete selectedColors[hex]; }\n  else { colorOrder.push({hex:hex,name:name}); selectedColors[hex]=name; }\n  refreshNums(); rebuildList(); updateColorBadge();\n}\nfunction refreshNums() {\n  document.querySelectorAll(\'.color-chip\').forEach(function(c){\n    c.classList.remove(\'selected\');\n    var b=c.querySelector(\'.check\'); if(b) b.textContent=\'\';\n  });\n  colorOrder.forEach(function(item,i){\n    var c=document.querySelector(\'.color-chip[data-hex="\'+item.hex+\'"]\');\n    if(!c) return;\n    c.classList.add(\'selected\');\n    c.querySelector(\'.check\').textContent=String(i+1);\n  });\n}\nfunction rebuildList() {\n  document.getElementById(\'assign-list\').innerHTML=\'\';\n  colorOrder.forEach(function(item,i){ addAssignRowForColor(item.hex,item.name,String(i+1)); });\n}\nfunction updateColorBadge() {\n  var b=document.getElementById(\'color-count-badge\');\n  if(b) b.textContent=colorOrder.length+\'개 선택\';\n}\nfunction addAssignRowForColor(hex, name, layerNum) {\n  name = name || hex;\n  var list=document.getElementById(\'assign-list\');\n  var row=document.createElement(\'div\'); row.className=\'assign-row\'; row.id=\'ar-\'+hex.replace(\'#\',\'\');\n  var preview=document.createElement(\'div\'); preview.className=\'assign-preview\'; preview.style.background=hex;\n  preview.onclick=function(){openRowPicker(preview,hex);};\n  var nameEl=document.createElement(\'span\'); nameEl.className=\'assign-name\'; nameEl.textContent=name;\n  var arrow=document.createElement(\'span\'); arrow.style.cssText=\'color:var(--muted);font-size:12px;\'; arrow.textContent=\'→\';\n  var select=document.createElement(\'select\'); select.className=\'slot-select\'; select.id=\'slot-\'+hex.replace(\'#\',\'\');\n  select.innerHTML=buildLayerOptions(layerNum);\n  var removeBtn=document.createElement(\'button\'); removeBtn.className=\'btn btn-sm btn-ghost\';\n  removeBtn.style.cssText=\'padding:4px 8px;margin-left:auto;font-size:11px;\'; removeBtn.textContent=\'✕\';\n  removeBtn.onclick=function(){removeAssignRow(hex);};\n  row.appendChild(preview);row.appendChild(nameEl);row.appendChild(arrow);row.appendChild(select);row.appendChild(removeBtn);\n  list.appendChild(row);\n}\nfunction buildLayerOptions(selected) {\n  var opts=\'<option value="">레이어</option>\';\n  for(var i=1;i<=14;i++) opts+=\'<option value="\'+i+\'"\'+(String(i)===String(selected)?\' selected\':\'\')+\'>\'+i+\'번</option>\';\n  return opts;\n}\nfunction removeAssignRow(hex) {\n  var idx=colorOrder.findIndex(function(x){return x.hex===hex;});\n  if(idx!==-1) colorOrder.splice(idx,1);\n  delete selectedColors[hex];\n  refreshNums(); rebuildList(); updateColorBadge();\n}\nfunction selectAllColors() {\n  document.querySelectorAll(\'.color-chip\').forEach(function(chip){\n    var hex=chip.getAttribute(\'data-hex\'), name=chip.getAttribute(\'data-name\')||hex;\n    if(!hex||selectedColors[hex]) return;\n    colorOrder.push({hex:hex,name:name}); selectedColors[hex]=name;\n  });\n  refreshNums(); rebuildList(); updateColorBadge();\n}\nfunction addColorFromPicker() {\n  var hex=document.getElementById(\'inline-color-picker\').value.toUpperCase();\n  if(selectedColors[hex]) return;\n  colorOrder.push({hex:hex,name:hex}); selectedColors[hex]=hex;\n  refreshNums(); rebuildList(); updateColorBadge();\n}\n\nfunction addAssignRow() { document.getElementById(\'hidden-color-input\').click(); }\ndocument.addEventListener(\'DOMContentLoaded\', function() {\n  var ci = document.getElementById(\'hidden-color-input\');\n  if (ci) {\n    ci.addEventListener(\'change\', function() {\n      var hex = this.value.toUpperCase();\n      if (selectedColors[hex]) return;\n      colorOrder.push({hex:hex,name:hex}); selectedColors[hex]=hex;\n      refreshNums(); rebuildList(); updateColorBadge();\n      this.value = \'#000000\';\n    });\n  }\n  loadSaved();\n});\nfunction openRowPicker(previewEl, currentHex) {\n  var input = document.createElement(\'input\');\n  input.type = \'color\'; input.value = currentHex;\n  input.style.cssText = \'position:absolute;opacity:0;pointer-events:none;width:0;height:0\';\n  document.body.appendChild(input);\n  input.addEventListener(\'change\', function() {\n    var newHex = this.value.toUpperCase();\n    var row = previewEl.closest(\'.assign-row\');\n    var oldHex = \'#\' + row.id.replace(\'ar-\',\'\');\n    previewEl.style.background = newHex;\n    row.id = \'ar-\' + newHex.replace(\'#\',\'\');\n    var label = row.querySelector(\'.assign-name\');\n    if (label) label.textContent = newHex;\n    var slot = row.querySelector(\'select\');\n    if (slot) slot.id = \'slot-\' + newHex.replace(\'#\',\'\');\n    var ci=colorOrder.findIndex(function(x){return x.hex===oldHex;});\n    if(ci!==-1){colorOrder[ci].hex=newHex;colorOrder[ci].name=newHex;}\n    delete selectedColors[oldHex]; selectedColors[newHex]=newHex;\n    refreshNums(); rebuildList();\n    document.body.removeChild(input);\n  });\n  input.click();\n}\nfunction selectLogo(name) {\n  selectedLogo = name;\n  [\'list_logo\',\'sistina_logo\',\'shesmiss_logo\'].forEach(function(n) {\n    document.getElementById(\'logo-\' + n).classList.toggle(\'active\', n===name);\n  });\n  var badge = document.getElementById(\'logo-badge\');\n  if (badge) badge.textContent = name===\'list_logo\'?\'LIST\':name===\'sistina_logo\'?\'SISTINA\':\'SHESMISS\';\n  try { localStorage.setItem(\'idf_resize_standard_logo\', name); } catch(e) {}\n}\nfunction generateJSX() {\n  var outputDir = document.getElementById(\'output-dir\').value.trim();\n  if (!outputDir) { setStatus(\'gen-status\',\'출력 폴더를 입력하세요\',\'err\'); return; }\n  var colorMap = {};\n  Object.keys(selectedColors).forEach(function(hex) {\n    var slot = document.getElementById(\'slot-\' + hex.replace(\'#\',\'\'));\n    if (slot && slot.value) colorMap[slot.value] = hex;\n  });\n  var imgCommon = document.getElementById(\'img_common\').value.trim();\n  var payload = {\n    psd: document.getElementById(\'psd\').value.trim(),\n    imgCommon: imgCommon,\n    img_600: imgCommon,\n    img_p: imgCommon,\n    img_ssf1: imgCommon,\n    img_ssf2: document.getElementById(\'img_ssf2\').value.trim(),\n    img_ssf3: document.getElementById(\'img_ssf3\').value.trim(),\n    img_1200: imgCommon,\n    logo: selectedLogo,\n    color_assignments: colorMap,\n    output_dir: outputDir\n  };\n  setStatus(\'gen-status\',\'스크립트 생성 중...\',\'\');\n  fetch(\'/generate?variant=standard\', {\n    method:\'POST\', headers:{\'Content-Type\':\'application/json\'},\n    body:JSON.stringify(payload)\n  })\n  .then(function(r) { return r.json(); })\n  .then(function(data) {\n    if (data.error) { setStatus(\'gen-status\',\'오류: \' + data.error,\'err\'); return; }\n    setStatus(\'gen-status\',\'✅ JSX 저장 완료: \' + data.path + \'<br>포토샵에서 File → Scripts → Browse 로 실행하세요\',\'ok\');\n  })\n  .catch(function(e) { setStatus(\'gen-status\',\'오류: \' + e,\'err\'); });\n}\nfunction resetAll() {\n\n  document.getElementById(\'url-input\').value = \'\';\n  document.getElementById(\'color-grid\').innerHTML = \'\';\n  document.getElementById(\'color-all-btn\').style.display = \'none\';\n  document.getElementById(\'assign-list\').innerHTML = \'\';\n  document.getElementById(\'step2\').style.display = \'none\';\n  setStatus(\'color-status\',\'URL을 입력하고 추출 버튼을 누르세요\',\'\');\n  selectedColors = {}; colorOrder = []; updateColorBadge();\n  [\'img_common\',\'img_ssf2\',\'img_ssf3\'].forEach(function(id) {\n    document.getElementById(id).value = \'\';\n  });\n  imgSel = [];\n  document.getElementById(\'img-section\').style.display = \'none\';\n  document.getElementById(\'img-grid\').innerHTML = \'\';\n  setStatus(\'gen-status\',\'설정 완료 후 버튼을 누르세요\',\'\');\n\n  window.scrollTo(0,0);\n}\nfunction setStatus(id, msg, cls) {\n  var el = document.getElementById(id);\n  el.innerHTML = msg;\n  el.className = \'status\' + (cls ? \' \' + cls : \'\');\n}\n</script>\n</body>\n</html>'
WCONCEPT_PAGE = '<!DOCTYPE html>\n<html lang="ko">\n<head>\n<meta charset="UTF-8">\n<meta name="viewport" content="width=device-width, initial-scale=1.0">\n<title>W컨셉 포함 버전</title>\n\n<style>\n:root {\n  --bg:#0d0a14; --s1:#130f1e; --s2:#1a1528; --s3:#221d30;\n  --border:rgba(160,120,255,0.1); --border2:rgba(160,120,255,0.22);\n  --text:#f0eeff; --muted:#7a6e9a; --muted2:#a89fc8;\n  --accent:#a855f7; --accent2:#c084fc;\n  --success:#a855f7; --danger:#f07070; --r:12px; --r-sm:8px;\n}\n*{box-sizing:border-box;margin:0;padding:0;}\nbody{background:var(--bg);color:var(--text);font-family:\'DM Sans\',sans-serif;font-size:14px;min-height:100vh;}\n.app-header{\n  position:sticky;top:0;z-index:100;\n  background:rgba(13,10,20,0.88);backdrop-filter:blur(20px);\n  border-bottom:1px solid var(--border);\n  padding:14px 24px;display:flex;align-items:center;justify-content:space-between;\n}\n.app-title{font-size:15px;font-weight:600;letter-spacing:-.3px;display:flex;align-items:center;gap:8px;}\n.app-title span{color:var(--accent);}\n.ab-badge{font-size:10px;background:rgba(168,85,247,0.15);color:var(--accent);border-radius:4px;padding:2px 8px;font-weight:500;}\n.main{max-width:860px;margin:0 auto;padding:28px 20px 60px;}\n.step{margin-bottom:12px;border-radius:var(--r);border:1px solid var(--border);overflow:hidden;transition:border-color .2s;}\n.step:focus-within{border-color:var(--border2);}\n.step-header{display:flex;align-items:center;gap:12px;padding:14px 18px;background:var(--s1);cursor:pointer;user-select:none;}\n.step-num{width:24px;height:24px;border-radius:50%;background:var(--s3);color:var(--muted2);font-size:11px;font-weight:600;display:flex;align-items:center;justify-content:center;flex-shrink:0;}\n.step.active .step-num{background:var(--accent);color:#fff;}\n.step-title{font-size:13px;font-weight:500;flex:1;}\n.step-badge{font-size:11px;color:var(--muted);background:var(--s3);padding:2px 8px;border-radius:20px;}\n.step-body{padding:18px;background:var(--s2);border-top:1px solid var(--border);}\ninput[type=text],input[type=url]{width:100%;background:var(--s3);border:1px solid var(--border);border-radius:var(--r-sm);color:var(--text);font-family:\'DM Sans\',sans-serif;font-size:13px;padding:10px 14px;outline:none;transition:border-color .2s;}\ninput:focus{border-color:rgba(168,85,247,0.5);}\ninput::placeholder{color:var(--muted);}\n.btn{background:var(--accent);border:none;border-radius:var(--r-sm);color:#fff;cursor:pointer;font-family:\'DM Sans\',sans-serif;font-size:13px;font-weight:600;padding:10px 20px;transition:background .15s,transform .1s;white-space:nowrap;}\n.btn:hover{background:var(--accent2);}\n.btn:active{transform:scale(.97);}\n.btn-ghost{background:transparent;border:1px solid var(--border2);color:var(--muted2);font-weight:400;}\n.btn-ghost:hover{background:var(--s3);color:var(--text);}\n.btn-danger{background:transparent;border:1px solid rgba(240,112,112,0.3);color:var(--danger);font-weight:400;}\n.btn-danger:hover{background:rgba(240,112,112,0.08);}\n.btn-sm{padding:7px 14px;font-size:12px;}\n.btn-full{width:100%;padding:15px;font-size:15px;border-radius:var(--r);}\n.color-grid{display:flex;flex-wrap:wrap;gap:10px;margin-top:14px;padding-bottom:24px;}\n.color-chip{width:40px;height:40px;border-radius:var(--r-sm);cursor:pointer;border:2px solid transparent;transition:transform .15s,border-color .15s;position:relative;flex-shrink:0;}\n.color-chip:hover{transform:scale(1.1);}\n.color-chip.selected{border-color:#c084fc;transform:scale(1.08);}\n.color-chip .check{position:absolute;top:3px;right:3px;width:18px;height:18px;background:rgba(80,0,160,0.85);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:800;color:#fff !important;opacity:0;transition:opacity .15s;line-height:1;}\n.color-chip.selected .check{opacity:1;}\n.chip-label{position:absolute;bottom:-20px;left:50%;transform:translateX(-50%);font-size:9px;white-space:nowrap;color:var(--muted);font-family:\'DM Mono\',monospace;pointer-events:none;}\n.assign-list{display:flex;flex-direction:column;gap:6px;}\n.assign-row{display:flex;align-items:center;gap:10px;background:var(--s3);border-radius:var(--r-sm);padding:8px 12px;border:1px solid var(--border);}\n.assign-preview{width:32px;height:32px;border-radius:6px;flex-shrink:0;cursor:pointer;border:1px solid rgba(255,255,255,0.1);}\n.assign-name{font-size:12px;font-family:\'DM Mono\',monospace;color:var(--muted2);min-width:90px;}\n.slot-select{background:var(--s2);border:1px solid var(--border);border-radius:6px;color:var(--text);font-family:\'DM Sans\',sans-serif;font-size:12px;padding:5px 10px;outline:none;}\n.logo-group{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;}\n.logo-btn{background:var(--s3);border:1px solid var(--border);border-radius:var(--r-sm);color:var(--muted2);font-family:\'DM Sans\',sans-serif;font-size:12px;font-weight:500;padding:12px;cursor:pointer;text-align:center;transition:all .2s;}\n.logo-btn.active{background:rgba(168,85,247,0.12);border-color:var(--accent);color:var(--accent);font-weight:600;}\n.ab-block{background:var(--s3);border:1px solid var(--border);border-radius:var(--r-sm);padding:14px;margin-bottom:10px;}\n.ab-block:last-child{margin-bottom:0;}\n.ab-block-title{font-size:11px;font-weight:600;letter-spacing:.5px;text-transform:uppercase;color:var(--accent);margin-bottom:10px;display:flex;align-items:center;gap:6px;}\n.ab-block-title .badge{background:rgba(168,85,247,0.1);color:var(--accent);border-radius:4px;font-size:10px;padding:1px 6px;}\n.field-label{font-size:11px;color:var(--muted);margin-bottom:5px;font-weight:500;}\n.saved-badge{display:inline-flex;align-items:center;gap:4px;font-size:10px;color:var(--accent);margin-left:6px;}\n.two-col{display:grid;grid-template-columns:1fr 1fr;gap:8px;}\n.status{background:var(--s3);border-radius:var(--r-sm);font-size:12px;padding:12px 16px;color:var(--muted);min-height:42px;line-height:1.6;border:1px solid var(--border);margin-top:10px;}\n.status.ok{color:var(--accent2);border-color:rgba(168,85,247,0.25);}\n.status.err{color:var(--danger);border-color:rgba(240,112,112,0.2);}\n.hint{font-size:11px;color:var(--muted);margin-bottom:12px;line-height:1.6;}\n.hint b{color:var(--muted2);}\n.img-slot-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-top:12px;}\n.img-slot{border:2px dashed rgba(168,85,247,0.2);border-radius:var(--r-sm);padding:8px;text-align:center;background:var(--s3);cursor:pointer;position:relative;transition:border-color .15s,transform .1s;}\n.img-slot:hover{border-color:rgba(168,85,247,0.55);transform:scale(1.02);}\n.img-slot.selected-1{border-style:solid;border-color:#a855f7;box-shadow:0 0 0 2px rgba(168,85,247,0.3);}\n.img-slot.selected-2{border-style:solid;border-color:#c084fc;box-shadow:0 0 0 2px rgba(192,132,252,0.3);}\n.img-slot.selected-3{border-style:solid;border-color:#d8b4fe;box-shadow:0 0 0 2px rgba(216,180,254,0.3);}\n.img-slot img{width:100%;height:80px;object-fit:cover;border-radius:6px;display:block;}\n.img-slot-badge{position:absolute;top:6px;left:6px;background:var(--accent);color:#fff;font-size:10px;font-weight:700;border-radius:4px;padding:2px 7px;display:none;}\n.img-slot.selected-1 .img-slot-badge,.img-slot.selected-2 .img-slot-badge,.img-slot.selected-3 .img-slot-badge{display:block;}\n.img-slot-label{font-size:9px;color:var(--muted);margin-top:5px;word-break:break-all;line-height:1.3;}\n.img-common-hl{background:rgba(168,85,247,0.07);border:1.5px solid rgba(168,85,247,0.35);border-radius:var(--r-sm);padding:14px;margin-bottom:10px;}\n.img-select-hint{font-size:11px;color:var(--muted2);margin-top:10px;padding:8px 12px;background:var(--s3);border-radius:var(--r-sm);border:1px solid var(--border);line-height:1.7;}\n.img-select-hint b{color:var(--accent);}\n</style>\n<style>\n:root{--bg:#f6f8f9;--s1:#f7f9fa;--s2:#fff;--s3:#f1f5f6;--border:#e0e6e8;--border2:#ccd7db;--text:#202a30;--muted:#65747c;--muted2:#4f6069;--accent:#087f70;--accent2:#066c5f;--success:#087f70;--danger:#bb3c4a;color-scheme:light}\nbody{background:var(--bg);color:var(--text);font:14px/1.6 Arial,\'Malgun Gothic\',sans-serif}button,input,select{font-family:inherit!important}.main{max-width:960px;padding:0 24px 50px;margin:0 auto}.step-title{font-size:14px;font-weight:600}.hint,.field-label,.ab-block-title,.step-badge,.saved-badge,.chip-label,.img-slot-name{font-size:12px}.btn,input[type=text],input[type=url],.logo-btn,.slot-select{font-size:14px}.btn{background:var(--accent);color:white}.btn:hover{background:var(--accent2)}.btn-ghost{background:transparent;color:var(--muted2);border-color:var(--border2)}.btn-ghost:hover{background:var(--s3);color:var(--text)}.logo-btn.active{background:#eaf7f3;border-color:var(--accent);color:var(--accent)}.step.active .step-num{background:var(--accent);color:white}.step-body{background:#fff}.step-header{background:var(--s1)}input::placeholder{color:#75838b}.status{color:var(--muted2)}:focus-visible{outline:2px solid var(--accent);outline-offset:2px}@media(max-width:560px){.main{padding:0 16px 36px}.two-col{grid-template-columns:1fr}}:root{--accent:#167d85;--accent2:#10646b}</style></head>\n<body>\n\n\n<main class="main">\n\n<!-- STEP 1 -->\n<div class="step active" id="step1">\n  <div class="step-header" onclick="toggleStep(\'step1\')">\n    <div class="step-num">1</div>\n    <div class="step-title">상세페이지 URL · 색상 & 이미지 추출</div>\n  </div>\n  <div class="step-body">\n    <div class="hint">idfmall 상품 URL을 붙여넣으면 <b>색상과 이미지를 동시에</b> 가져와요.</div>\n    <div style="display:flex;gap:8px">\n      <input type="url" id="url-input" placeholder="https://idfmall.co.kr/product/detail.html?..." style="flex:1">\n      <button class="btn" onclick="fetchAll()" id="extract-btn">✦ 추출</button>\n    </div>\n    <div id="color-status" class="status">URL을 입력하고 추출 버튼을 누르세요</div>\n    <div id="img-slot-section" style="display:none;margin-top:14px">\n      <div style="font-size:11px;font-weight:700;letter-spacing:.6px;text-transform:uppercase;color:var(--accent);margin-bottom:8px;display:flex;align-items:center;gap:6px;">\n        🖼 추출된 이미지 <span id="img-count-badge" style="background:rgba(168,85,247,0.12);color:var(--accent2);border-radius:4px;font-size:10px;padding:1px 7px;font-weight:500;"></span>\n        <span style="font-size:10px;color:var(--muted);font-weight:400;">— 클릭 순서대로 공통·SSF2·SSF3에 입력</span>\n      </div>\n      <div class="img-slot-grid" id="img-slot-grid"></div>\n    </div>\n    <div id="color-all-btn" style="display:none;margin-top:8px">\n      <button class="btn btn-sm btn-ghost" onclick="selectAllColors()" style="width:100%">✦ 전체 선택</button>\n    </div>\n    <div id="color-grid" class="color-grid"></div>\n  </div>\n</div>\n\n<!-- STEP 2 -->\n<div class="step" id="step2" style="display:none">\n  <div class="step-header" onclick="toggleStep(\'step2\')">\n    <div class="step-num">2</div>\n    <div class="step-title">컬러 → 레이어 배치</div>\n    <div class="step-badge" id="color-count-badge">0개 선택</div>\n  </div>\n  <div class="step-body">\n    <div class="hint">색상 칩을 클릭하면 <b>1번부터 자동 배정</b>돼요.</div>\n    <div class="assign-list" id="assign-list"></div>\n    <div style="margin-top:10px;display:flex;align-items:center;gap:8px">\n      <input type="color" id="inline-color-picker" value="#000000" style="width:40px;height:36px;border:1px solid var(--border2);border-radius:var(--r-sm);background:var(--s3);cursor:pointer;padding:2px;">\n      <button class="btn btn-sm btn-ghost" onclick="addColorFromPicker()">+ 추가하기</button>\n      <input type="color" id="hidden-color-input" style="position:absolute;opacity:0;pointer-events:none;width:0;height:0">\n    </div>\n  </div>\n</div>\n\n<!-- STEP 3 -->\n<div class="step" id="step3">\n  <div class="step-header" onclick="toggleStep(\'step3\')">\n    <div class="step-num">3</div>\n    <div class="step-title">로고 선택</div>\n    <div class="step-badge" id="logo-badge">LIST</div>\n  </div>\n  <div class="step-body">\n    <div class="logo-group">\n      <button class="logo-btn active" id="logo-list_logo" onclick="selectLogo(\'list_logo\')">LIST</button>\n      <button class="logo-btn" id="logo-sistina_logo" onclick="selectLogo(\'sistina_logo\')">SISTINA</button>\n      <button class="logo-btn" id="logo-shesmiss_logo" onclick="selectLogo(\'shesmiss_logo\')">SHESMISS</button>\n    </div>\n  </div>\n</div>\n\n<!-- STEP 4 -->\n<div class="step" id="step4">\n  <div class="step-header" onclick="toggleStep(\'step4\')">\n    <div class="step-num">4</div>\n    <div class="step-title">아트보드 PSD & 이미지 경로</div>\n    <div class="step-badge">경로 자동 저장</div>\n  </div>\n  <div class="step-body">\n    <div class="hint"><b>PSD 경로</b>는 자동 저장돼요. 이미지만 바꿔서 반복 작업 가능!<br>이미지는 <b>로컬 경로</b> 또는 <b>URL</b>(우클릭 → 이미지 주소 복사) 모두 가능해요.</div>\n    <div class="ab-block">\n      <div class="ab-block-title">📄 아트보드 PSD <span class="badge">1개 파일에 6개 아트보드</span></div>\n      <div class="field-label">PSD 경로 <span class="saved-badge" id="saved-psd" style="display:none">✓ 저장됨</span></div>\n      <input type="text" id="psd" placeholder="아트보드_템플릿.psd 경로" oninput="savePsdPath(\'psd\',this.value)">\n    </div>\n    <div class="img-common-hl">\n      <div style="font-size:11px;font-weight:700;letter-spacing:.8px;text-transform:uppercase;color:var(--accent);margin-bottom:4px;display:flex;align-items:center;gap:6px;">\n        🖼 공통 이미지\n        <span style="background:rgba(168,85,247,0.15);color:var(--accent2);border-radius:4px;font-size:10px;padding:1px 7px;font-weight:500;">600 · P · SSF_01 · 1200 동일 적용</span>\n      </div>\n      <div style="font-size:11px;color:var(--muted);margin-bottom:8px;">이미지 하나로 4개 아트보드에 자동으로 들어가요</div>\n      <input type="text" id="img_common" placeholder="경로 또는 https://..." style="border-color:rgba(168,85,247,0.25);">\n    </div>\n    <div class="ab-block">\n      <div class="ab-block-title">🖼 SSF_02 / SSF_03 <span class="badge">1500×2000 · 별도 이미지</span></div>\n      <div style="display:flex;flex-direction:column;gap:6px">\n        <div>\n          <div class="field-label">SSF_02 이미지</div>\n          <input type="text" id="img_ssf2" placeholder="경로 또는 https://...">\n        </div>\n        <div>\n          <div class="field-label">SSF_03 이미지</div>\n          <input type="text" id="img_ssf3" placeholder="경로 또는 https://...">\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n\n<!-- STEP 5 -->\n<div class="step" id="step5">\n  <div class="step-header" onclick="toggleStep(\'step5\')">\n    <div class="step-num">5</div>\n    <div class="step-title">출력 폴더</div>\n    <div class="step-badge" id="saved-output-badge" style="display:none">저장됨</div>\n  </div>\n  <div class="step-body">\n    <div class="hint">완성된 PSD가 저장될 폴더예요.</div>\n    <input type="text" id="output-dir" placeholder="C:\\Users\\...\\Output" oninput="saveOutputDir(this.value)">\n  </div>\n</div>\n\n<div style="height:16px"></div>\n<button class="btn btn-full" onclick="generateJSX()">🚀 JSX 스크립트 생성</button>\n<div id="gen-status" class="status">설정 완료 후 버튼을 누르세요</div>\n\n</main>\n\n<script>\nvar selectedColors = {};\nvar selectedLogo = \'list_logo\';\nvar SLOT_TARGETS = [\'img_common\', \'img_ssf2\', \'img_ssf3\'];\nvar SLOT_NAMES   = [\'공통 이미지\', \'SSF_02\', \'SSF_03\'];\n\nfunction savePsdPath(key, val) {\n  try { localStorage.setItem(\'idf_resize_wconcept_\' + key, val); } catch(e) {}\n  var badge = document.getElementById(\'saved-\' + key);\n  if (badge) badge.style.display = val ? \'inline-flex\' : \'none\';\n}\nfunction saveOutputDir(val) {\n  try { localStorage.setItem(\'idf_resize_wconcept_output\', val); } catch(e) {}\n  var badge = document.getElementById(\'saved-output-badge\');\n  if (badge) badge.style.display = val ? \'inline\' : \'none\';\n}\nfunction loadSaved() {\n  try { var sl = localStorage.getItem(\'idf_resize_wconcept_logo\'); if (sl) selectLogo(sl); } catch(e) {}\n  try {\n    var psd = localStorage.getItem(\'idf_resize_wconcept_psd\');\n    if (psd) { document.getElementById(\'psd\').value = psd; document.getElementById(\'saved-psd\').style.display = \'inline-flex\'; }\n    var out = localStorage.getItem(\'idf_resize_wconcept_output\');\n    if (out) { document.getElementById(\'output-dir\').value = out; document.getElementById(\'saved-output-badge\').style.display = \'inline\'; }\n  } catch(e) {}\n}\nfunction toggleStep(id) {\n  var body = document.querySelector(\'#\' + id + \' .step-body\');\n  if (body) body.style.display = body.style.display === \'none\' ? \'\' : \'none\';\n}\n\n// ── 통합 추출 ─────────────────────────────────────────\nfunction fetchAll() {\n  var url = document.getElementById(\'url-input\').value.trim();\n  if (!url) { setStatus(\'color-status\',\'URL을 입력하세요\',\'err\'); return; }\n  var btn = document.getElementById(\'extract-btn\');\n  btn.disabled = true; btn.textContent = \'추출 중...\';\n  setStatus(\'color-status\',\'색상과 이미지를 가져오는 중...\',\'\');\n  var colorDone = false, imgDone = false, colorResult = null, imgResult = null;\n  function tryFinish() {\n    if (!colorDone || !imgDone) return;\n    btn.disabled = false; btn.textContent = \'✦ 추출\';\n    if (colorResult && !colorResult.error) {\n      renderColorGrid(colorResult.colors);\n      document.getElementById(\'color-all-btn\').style.display = \'\';\n      var s2 = document.getElementById(\'step2\');\n      s2.style.display = \'\';\n      var s2body = s2.querySelector(\'.step-body\');\n      if (s2body) s2body.style.display = \'none\';\n    }\n    if (imgResult && imgResult.ok && imgResult.images && imgResult.images.length > 0) {\n      renderImageSlots(imgResult.images);\n    }\n    var cCount = (colorResult && !colorResult.error) ? colorResult.colors.length : 0;\n    var iCount = (imgResult && imgResult.ok) ? imgResult.images.length : 0;\n    if (cCount > 0 || iCount > 0) {\n      setStatus(\'color-status\', \'✅ 색상 \' + cCount + \'개 · 이미지 \' + iCount + \'개 추출 완료\', \'ok\');\n    } else {\n      setStatus(\'color-status\', \'추출된 항목이 없어요. URL을 확인해 주세요.\', \'err\');\n    }\n  }\n  fetch(\'/extract?url=\' + encodeURIComponent(url))\n    .then(function(r){return r.json();})\n    .then(function(d){colorResult=d;colorDone=true;tryFinish();})\n    .catch(function(){colorResult={error:\'실패\',colors:[]};colorDone=true;tryFinish();});\n  fetch(\'/extract_images?url=\' + encodeURIComponent(url))\n    .then(function(r){return r.json();})\n    .then(function(d){imgResult=d;imgDone=true;tryFinish();})\n    .catch(function(){imgResult={ok:false,images:[]};imgDone=true;tryFinish();});\n}\n\nvar imgSelectOrder = []; // 선택 순서 기록 [{url, slotEl}]\n\nfunction renderImageSlots(images) {\n  var grid = document.getElementById(\'img-slot-grid\');\n  var section = document.getElementById(\'img-slot-section\');\n  var badge = document.getElementById(\'img-count-badge\');\n  grid.innerHTML = \'\';\n  imgSelectOrder = [];\n  badge.textContent = images.length + \'개\';\n  section.style.display = \'\';\n\n  images.forEach(function(imgUrl, idx) {\n    var slot = document.createElement(\'div\');\n    slot.className = \'img-slot\';\n    slot.setAttribute(\'data-url\', imgUrl);\n\n    // 순서 뱃지\n    var badge2 = document.createElement(\'div\');\n    badge2.className = \'img-slot-badge\';\n    slot.appendChild(badge2);\n\n    var img = document.createElement(\'img\');\n    img.src = imgUrl;\n    img.referrerPolicy = \'no-referrer\';\n    img.onerror = function() {\n      var proxyUrl = \'/proxy?url=\' + encodeURIComponent(imgUrl);\n      if (img.src.indexOf(\'/proxy?url=\') === -1) {\n        img.src = proxyUrl;\n      } else {\n        img.style.display = \'none\';\n      }\n    };\n    slot.appendChild(img);\n\n    var lbl = document.createElement(\'div\');\n    lbl.className = \'img-slot-label\';\n    lbl.textContent = imgUrl.split(\'/\').pop();\n    slot.appendChild(lbl);\n\n    slot.onclick = function() { toggleImgSelect(slot, imgUrl); };\n    grid.appendChild(slot);\n  });\n\n  // 선택 힌트\n  var hint = document.createElement(\'div\');\n  hint.className = \'img-select-hint\';\n  hint.id = \'img-select-hint\';\n  hint.innerHTML = \'<b>1번째</b> 클릭 → 공통 이미지 &nbsp;·&nbsp; <b>2번째</b> → SSF_02 &nbsp;·&nbsp; <b>3번째</b> → SSF_03\';\n  grid.parentNode.insertBefore(hint, grid.nextSibling);\n}\n\nfunction toggleImgSelect(slotEl, imgUrl) {\n  // 이미 선택된 슬롯이면 해제\n  var existIdx = -1;\n  for (var i = 0; i < imgSelectOrder.length; i++) {\n    if (imgSelectOrder[i].slot === slotEl) { existIdx = i; break; }\n  }\n  if (existIdx !== -1) {\n    // 선택 해제\n    imgSelectOrder.splice(existIdx, 1);\n    // 전체 재렌더 뱃지\n    refreshBadges();\n    // 해당 입력 비우기\n    rebuildInputs();\n    return;\n  }\n  // 최대 3개\n  if (imgSelectOrder.length >= 3) {\n    // 첫 번째 선택 해제하고 새로 추가\n    var first = imgSelectOrder.shift();\n    first.slot.className = \'img-slot\';\n    first.slot.querySelector(\'.img-slot-badge\').textContent = \'\';\n  }\n  imgSelectOrder.push({slot: slotEl, url: imgUrl});\n  refreshBadges();\n  rebuildInputs();\n}\n\nfunction refreshBadges() {\n  // 전체 슬롯 초기화\n  document.querySelectorAll(\'.img-slot\').forEach(function(s) {\n    s.className = \'img-slot\';\n    s.querySelector(\'.img-slot-badge\').textContent = \'\';\n  });\n  var labels = [\'1 · 공통\', \'2 · SSF2\', \'3 · SSF3\'];\n  var classes = [\'selected-1\', \'selected-2\', \'selected-3\'];\n  imgSelectOrder.forEach(function(item, i) {\n    item.slot.className = \'img-slot \' + classes[i];\n    item.slot.querySelector(\'.img-slot-badge\').textContent = labels[i];\n  });\n  // 힌트 업데이트\n  var hint = document.getElementById(\'img-select-hint\');\n  if (!hint) return;\n  var next = imgSelectOrder.length + 1;\n  var nextNames = [\'공통 이미지\', \'SSF_02\', \'SSF_03\'];\n  if (imgSelectOrder.length < 3) {\n    hint.innerHTML = \'선택 \' + imgSelectOrder.length + \'/3 &nbsp;—&nbsp; <b>\' + next + \'번째</b> 클릭 → \' + nextNames[imgSelectOrder.length];\n  } else {\n    hint.innerHTML = \'✅ 3개 선택 완료! STEP 4에 자동 입력됐어요.\';\n  }\n}\n\nfunction rebuildInputs() {\n  // 먼저 3개 슬롯 전부 비우기\n  SLOT_TARGETS.forEach(function(id) { document.getElementById(id).value = \'\'; });\n  // 선택 순서대로 입력\n  imgSelectOrder.forEach(function(item, i) {\n    document.getElementById(SLOT_TARGETS[i]).value = item.url;\n  });\n}\n\n// ── 색상 선택 (순서 기반) ─────────────────────────────\nvar colorOrder = []; // 클릭 순서 배열 [{hex, name}]\n\nfunction colorBright(hex) {\n  var r=parseInt(hex.slice(1,3),16),g=parseInt(hex.slice(3,5),16),b=parseInt(hex.slice(5,7),16);\n  return (r*299+g*587+b*114)/1000;\n}\nfunction isDark(hex) { return colorBright(hex) < 128; }\n\nfunction makeChip(hex, name) {\n  var chip = document.createElement(\'div\');\n  chip.className = \'color-chip\';\n  chip.style.background = hex;\n  chip.title = name + \' \' + hex;\n  chip.setAttribute(\'data-hex\', hex);\n  chip.setAttribute(\'data-name\', name);\n  var label = document.createElement(\'div\');\n  label.className = \'chip-label\';\n  label.textContent = name;\n  chip.appendChild(label);\n  var numBadge = document.createElement(\'span\');\n  numBadge.className = \'check\';\n  chip.appendChild(numBadge);\n  chip.onclick = function() { toggleColor(hex, name); };\n  return chip;\n}\n\nfunction renderColorGrid(colors) {\n  var grid = document.getElementById(\'color-grid\');\n  grid.innerHTML = \'\';\n  colorOrder = []; selectedColors = {};\n\n  var BLACK = \'#1A1A1A\', WHITE = \'#FFFFFF\';\n\n  // 블랙: 맨 앞 고정\n  grid.appendChild(makeChip(BLACK, \'Black\'));\n\n  // 추출된 색상 (블랙·화이트와 겹치면 제외)\n  colors.forEach(function(item) {\n    var h = item.hex.toUpperCase();\n    if (h === BLACK.toUpperCase() || h === WHITE.toUpperCase()) return;\n    grid.appendChild(makeChip(item.hex, item.name));\n  });\n\n  // 화이트: 맨 뒤 고정\n  grid.appendChild(makeChip(WHITE, \'White\'));\n}\n\nfunction toggleColor(hex, name) {\n  var idx = -1;\n  for (var i = 0; i < colorOrder.length; i++) { if (colorOrder[i].hex === hex) { idx = i; break; } }\n  if (idx !== -1) {\n    colorOrder.splice(idx, 1);\n    delete selectedColors[hex];\n  } else {\n    colorOrder.push({hex:hex, name:name});\n    selectedColors[hex] = name;\n  }\n  refreshChipNumbers();\n  rebuildAssignList();\n  updateColorBadge();\n}\n\nfunction refreshChipNumbers() {\n  document.querySelectorAll(\'.color-chip\').forEach(function(chip) {\n    chip.classList.remove(\'selected\');\n    var b = chip.querySelector(\'.check\');\n    if (b) b.textContent = \'\';\n  });\n  colorOrder.forEach(function(item, i) {\n    var chip = document.querySelector(\'.color-chip[data-hex="\' + item.hex + \'"]\');\n    if (!chip) return;\n    chip.classList.add(\'selected\');\n    var b = chip.querySelector(\'.check\');\n    if (b) b.textContent = String(i + 1);\n  });\n}\n\nfunction rebuildAssignList() {\n  var list = document.getElementById(\'assign-list\');\n  list.innerHTML = \'\';\n  colorOrder.forEach(function(item, i) {\n    addAssignRowForColor(item.hex, item.name, String(i + 1));\n  });\n}\n\nfunction updateColorBadge() {\n  var b = document.getElementById(\'color-count-badge\');\n  if (b) b.textContent = colorOrder.length + \'개 선택\';\n}\n\nfunction addAssignRowForColor(hex, name, layerNum) {\n  name = name || hex;\n  var list = document.getElementById(\'assign-list\');\n  var row = document.createElement(\'div\');\n  row.className = \'assign-row\'; row.id = \'ar-\' + hex.replace(\'#\',\'\');\n  var preview = document.createElement(\'div\');\n  preview.className = \'assign-preview\'; preview.style.background = hex;\n  preview.onclick = function(){openRowPicker(preview,hex);};\n  var nameEl = document.createElement(\'span\');\n  nameEl.className = \'assign-name\'; nameEl.textContent = name;\n  var arrow = document.createElement(\'span\');\n  arrow.style.cssText = \'color:var(--muted);font-size:12px;\'; arrow.textContent = \'→\';\n  var select = document.createElement(\'select\');\n  select.className = \'slot-select\'; select.id = \'slot-\' + hex.replace(\'#\',\'\');\n  select.innerHTML = buildLayerOptions(layerNum);\n  var removeBtn = document.createElement(\'button\');\n  removeBtn.className = \'btn btn-sm btn-ghost\';\n  removeBtn.style.cssText = \'padding:4px 8px;margin-left:auto;font-size:11px;\';\n  removeBtn.textContent = \'✕\';\n  removeBtn.onclick = function(){removeAssignRow(hex);};\n  row.appendChild(preview);row.appendChild(nameEl);row.appendChild(arrow);\n  row.appendChild(select);row.appendChild(removeBtn);\n  list.appendChild(row);\n}\n\nfunction buildLayerOptions(selected) {\n  var opts = \'<option value="">레이어</option>\';\n  for (var i=1;i<=14;i++) opts += \'<option value="\'+i+\'"\'+(String(i)===String(selected)?\' selected\':\'\')+\'>\'+i+\'번</option>\';\n  return opts;\n}\n\nfunction removeAssignRow(hex) {\n  var idx = -1;\n  for (var i = 0; i < colorOrder.length; i++) { if (colorOrder[i].hex === hex) { idx = i; break; } }\n  if (idx !== -1) colorOrder.splice(idx, 1);\n  delete selectedColors[hex];\n  refreshChipNumbers();\n  rebuildAssignList();\n  updateColorBadge();\n}\n\nfunction selectAllColors() {\n  document.querySelectorAll(\'.color-chip\').forEach(function(chip) {\n    var hex = chip.getAttribute(\'data-hex\');\n    var name = chip.getAttribute(\'data-name\') || hex;\n    if (!hex || selectedColors[hex]) return;\n    colorOrder.push({hex:hex, name:name});\n    selectedColors[hex] = name;\n  });\n  refreshChipNumbers();\n  rebuildAssignList();\n  updateColorBadge();\n}\n\nfunction addColorFromPicker() {\n  var hex = document.getElementById(\'inline-color-picker\').value.toUpperCase();\n  if (selectedColors[hex]) return;\n  colorOrder.push({hex:hex, name:hex});\n  selectedColors[hex] = hex;\n  refreshChipNumbers();\n  rebuildAssignList();\n  updateColorBadge();\n}\ndocument.addEventListener(\'DOMContentLoaded\', function() {\n  var ci = document.getElementById(\'hidden-color-input\');\n  if (ci) {\n    ci.addEventListener(\'change\', function() {\n      var hex = this.value.toUpperCase();\n      if (selectedColors[hex]) return;\n      selectedColors[hex] = hex; addAssignRowForColor(hex, hex); updateColorBadge();\n      this.value = \'#000000\';\n    });\n  }\n  loadSaved();\n});\nfunction openRowPicker(previewEl, currentHex) {\n  var input = document.createElement(\'input\');\n  input.type = \'color\'; input.value = currentHex;\n  input.style.cssText = \'position:absolute;opacity:0;pointer-events:none;width:0;height:0\';\n  document.body.appendChild(input);\n  input.addEventListener(\'change\', function() {\n    var newHex = this.value.toUpperCase();\n    var row = previewEl.closest(\'.assign-row\');\n    var oldHex = \'#\' + row.id.replace(\'ar-\',\'\');\n    previewEl.style.background = newHex;\n    row.id = \'ar-\' + newHex.replace(\'#\',\'\');\n    var label = row.querySelector(\'.assign-name\');\n    if (label) label.textContent = newHex;\n    var slot = row.querySelector(\'select\');\n    if (slot) slot.id = \'slot-\' + newHex.replace(\'#\',\'\');\n    var cidx = -1;\n    for (var ci=0;ci<colorOrder.length;ci++){if(colorOrder[ci].hex===oldHex){cidx=ci;break;}}\n    if (cidx !== -1){colorOrder[cidx].hex=newHex;colorOrder[cidx].name=newHex;}\n    delete selectedColors[oldHex]; selectedColors[newHex] = newHex;\n    refreshChipNumbers(); rebuildAssignList();\n    document.body.removeChild(input);\n  });\n  input.click();\n}\nfunction selectLogo(name) {\n  selectedLogo = name;\n  [\'list_logo\',\'sistina_logo\',\'shesmiss_logo\'].forEach(function(n){\n    document.getElementById(\'logo-\' + n).classList.toggle(\'active\', n===name);\n  });\n  var badge = document.getElementById(\'logo-badge\');\n  if (badge) badge.textContent = name===\'list_logo\'?\'LIST\':name===\'sistina_logo\'?\'SISTINA\':\'SHESMISS\';\n  try { localStorage.setItem(\'idf_resize_wconcept_logo\', name); } catch(e) {}\n}\nfunction generateJSX() {\n  var outputDir = document.getElementById(\'output-dir\').value.trim();\n  if (!outputDir) { setStatus(\'gen-status\',\'출력 폴더를 입력하세요\',\'err\'); return; }\n  var colorMap = {};\n  Object.keys(selectedColors).forEach(function(hex) {\n    var slot = document.getElementById(\'slot-\' + hex.replace(\'#\',\'\'));\n    if (slot && slot.value) colorMap[slot.value] = hex;\n  });\n  var imgCommon = document.getElementById(\'img_common\').value.trim();\n  var payload = {\n    psd: document.getElementById(\'psd\').value.trim(),\n    imgCommon: imgCommon, img_600: imgCommon, img_p: imgCommon,\n    img_ssf1: imgCommon,\n    img_ssf2: document.getElementById(\'img_ssf2\').value.trim(),\n    img_ssf3: document.getElementById(\'img_ssf3\').value.trim(),\n    img_1200: imgCommon, logo: selectedLogo,\n    color_assignments: colorMap, output_dir: outputDir\n  };\n  setStatus(\'gen-status\',\'스크립트 생성 중...\',\'\');\n  fetch(\'/generate?variant=wconcept\', {method:\'POST\',headers:{\'Content-Type\':\'application/json\'},body:JSON.stringify(payload)})\n  .then(function(r){return r.json();})\n  .then(function(data){\n    if (data.error){setStatus(\'gen-status\',\'오류: \'+data.error,\'err\');return;}\n    setStatus(\'gen-status\',\'✅ JSX 저장 완료: \'+data.path+\'<br>포토샵에서 File → Scripts → Browse 로 실행하세요\',\'ok\');\n  })\n  .catch(function(e){setStatus(\'gen-status\',\'오류: \'+e,\'err\');});\n}\nfunction resetAll() {\n  document.getElementById(\'url-input\').value = \'\';\n  document.getElementById(\'color-grid\').innerHTML = \'\';\n  document.getElementById(\'color-all-btn\').style.display = \'none\';\n  document.getElementById(\'assign-list\').innerHTML = \'\';\n  document.getElementById(\'step2\').style.display = \'none\';\n  setStatus(\'color-status\',\'URL을 입력하고 추출 버튼을 누르세요\',\'\');\n  selectedColors = {}; colorOrder = []; updateColorBadge();\n  [\'img_common\',\'img_ssf2\',\'img_ssf3\'].forEach(function(id){document.getElementById(id).value=\'\';});\n  document.getElementById(\'img-slot-section\').style.display = \'none\';\n  document.getElementById(\'img-slot-grid\').innerHTML = \'\';\n  setStatus(\'gen-status\',\'설정 완료 후 버튼을 누르세요\',\'\');\n  window.scrollTo(0,0);\n}\nfunction setStatus(id, msg, cls) {\n  var el = document.getElementById(id);\n  el.innerHTML = msg;\n  el.className = \'status\' + (cls ? \' \' + cls : \'\');\n}\n</script>\n</body>\n</html>'

class Handler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def do_GET(self):
        if self.path in ('/standard', '/wconcept'):
            page = STANDARD_PAGE if self.path == '/standard' else WCONCEPT_PAGE
            self._send(200, 'text/html; charset=utf-8', page.encode('utf-8'))
            return
        if self.path == '/health':
            self._send(200, 'text/plain', b'IDF_RESIZE_UNIFIED_V1')
            return
        if self.path == '/' or self.path == '/index.html':
            self._send(200, 'text/html; charset=utf-8', HTML_PAGE.encode())
        elif self.path.startswith('/proxy'):
            parsed = urllib.parse.urlparse(self.path)
            params = urllib.parse.parse_qs(parsed.query)
            target = params.get('url',[None])[0]
            if not target:
                self._send(400,'text/plain',b'Missing url'); return
            try:
                import ssl, http.cookiejar
                ctx = ssl.create_default_context()
                ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
                cj = http.cookiejar.CookieJar()
                opener = urllib.request.build_opener(
                    urllib.request.HTTPCookieProcessor(cj),
                    urllib.request.HTTPSHandler(context=ctx))
                opener.addheaders = [
                    ('User-Agent','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'),
                    ('Accept','image/avif,image/webp,image/apng,image/*,*/*;q=0.8'),
                    ('Accept-Language','ko-KR,ko;q=0.9'),
                    ('Referer','https://idfmall.co.kr/'),
                    ('Origin','https://idfmall.co.kr'),
                ]
                resp = opener.open(target, timeout=20)
                data = resp.read()
                ct = resp.headers.get('Content-Type','image/jpeg')
                self.send_response(200)
                self.send_header('Content-Type', ct)
                self.send_header('Content-Length', str(len(data)))
                self.send_header('Access-Control-Allow-Origin','*')
                self.end_headers()
                self.wfile.write(data)
            except Exception as e:
                self._send(502,'text/plain',('Proxy error: '+str(e)).encode())
            return
        elif self.path.startswith('/extract_images'):
            parsed = urllib.parse.urlparse(self.path)
            params = urllib.parse.parse_qs(parsed.query)
            url = params.get('url',[''])[0]
            self._send(200,'application/json',json.dumps(fetch_images(url)).encode())
        elif self.path.startswith('/extract'):
            parsed = urllib.parse.urlparse(self.path)
            params = urllib.parse.parse_qs(parsed.query)
            url = params.get('url', [''])[0]
            result = fetch_colors(url)
            self._send(200, 'application/json', json.dumps(result).encode())
        else:
            self._send(404, 'text/plain', b'Not found')

    def do_POST(self):
        try:
            parsed = urllib.parse.urlparse(self.path)
            variant = urllib.parse.parse_qs(parsed.query).get('variant', ['standard'])[0]
            origin = self.headers.get('Origin')
            expected = 'http://' + self.headers.get('Host', '')
            if origin and origin != expected:
                self._send(403, 'text/plain', b'Forbidden origin'); return
            if not self.headers.get('Content-Type', '').startswith('application/json'):
                self._send(415, 'text/plain', b'JSON required'); return
            if variant not in ('standard', 'wconcept') or parsed.path != '/generate':
                self._send(404, 'text/plain; charset=utf-8', b'Not found')
                return

            length_text = self.headers.get('Content-Length', '0')
            try:
                length = int(length_text)
            except ValueError:
                self._send(400, 'application/json; charset=utf-8', json.dumps({
                    'error': '잘못된 Content-Length입니다.'
                }, ensure_ascii=False).encode('utf-8'))
                return

            raw = self.rfile.read(length)
            try:
                config = json.loads(raw.decode('utf-8'))
            except Exception as e:
                self._send(400, 'application/json; charset=utf-8', json.dumps({
                    'error': '요청 데이터(JSON)를 읽지 못했습니다: ' + str(e)
                }, ensure_ascii=False).encode('utf-8'))
                return

            out_dir = str(config.get('output_dir') or os.path.expanduser('~')).strip().strip('"').strip("'")
            if not out_dir:
                self._send(400, 'application/json; charset=utf-8', json.dumps({
                    'error': '출력 폴더가 비어 있습니다.'
                }, ensure_ascii=False).encode('utf-8'))
                return

            try:
                os.makedirs(out_dir, exist_ok=True)
            except Exception as e:
                self._send(500, 'application/json; charset=utf-8', json.dumps({
                    'error': '출력 폴더를 만들 수 없습니다: ' + str(e)
                }, ensure_ascii=False).encode('utf-8'))
                return

            # 같은 이미지 URL은 한 번만 다운로드해서 재사용
            download_cache = {}
            img_keys = ['img_600', 'img_p', 'imgCommon', 'img_ssf1', 'img_ssf2', 'img_ssf3', 'img_1200']
            for key in img_keys:
                p = config.get(key, '')
                if p:
                    result = resolve_image_path(p, out_dir, download_cache)
                    if isinstance(result, dict):
                        self._send(500, 'application/json; charset=utf-8', json.dumps(
                            result, ensure_ascii=False
                        ).encode('utf-8'))
                        return
                    config[key] = result

            try:
                jsx = (build_jsx_standard if variant == 'standard' else build_jsx_wconcept)(config)
                save_path = os.path.join(out_dir, 'photoshop_auto_artboard.jsx' if variant == 'standard' else 'photoshop_auto_artboard_wconcept.jsx')
                with open(save_path, 'w', encoding='utf-8') as f:
                    f.write(jsx)
            except Exception as e:
                self._send(500, 'application/json; charset=utf-8', json.dumps({
                    'error': 'JSX 생성 또는 저장 실패: ' + str(e)
                }, ensure_ascii=False).encode('utf-8'))
                return

            self._send(200, 'application/json; charset=utf-8', json.dumps({
                'path': save_path
            }, ensure_ascii=False).encode('utf-8'))

        except Exception as e:
            # 서버 연결이 끊기지 않고 브라우저에 실제 오류를 반환하도록 최종 방어
            try:
                self._send(500, 'application/json; charset=utf-8', json.dumps({
                    'error': '서버 처리 중 오류: ' + str(e)
                }, ensure_ascii=False).encode('utf-8'))
            except Exception:
                pass

    def _send(self, code, ct, body):
        self.send_response(code)
        self.send_header('Content-Type', ct)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()
        self.wfile.write(body)

def main():
    import webbrowser
    import threading
    port = 5053
    url = 'http://localhost:%s/' % port
    try:
        server = HTTPServer(('127.0.0.1', port), Handler)
    except OSError:
        try:
            with urllib.request.urlopen(url + 'health', timeout=2) as response:
                if response.read() == b'IDF_RESIZE_UNIFIED_V1':
                    webbrowser.open(url)
                    print('Already running. Browser opened.')
                    return
        except Exception:
            pass
        raise SystemExit('Port 5053 is in use. Close the other application and try again.')
    print('IDF STUDIO - Thumbnail Resizing')
    print(url)
    print('Keep this window open. Press Ctrl+C to stop.')
    threading.Timer(0.7, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print('Stopped.')
    finally:
        server.server_close()

if __name__ == '__main__':
    main()
