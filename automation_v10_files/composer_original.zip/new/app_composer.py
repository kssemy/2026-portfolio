#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Detail Page Composer Server v2.0.0
"""

import http.server
import socketserver
import webbrowser
import os
import sys
import threading
import urllib.request
import urllib.parse
import json
import base64
import re
import gzip
import http.cookiejar
import socket
import zlib
import ssl
from html.parser import HTMLParser

PORT = 5500
HTML_FILE = "DetailPageComposer.html"

USER_AGENT = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
              '(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36')
IMAGE_TYPES = {'image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/avif', 'image/bmp'}
COLOR_CODES = {
    'BLACK': 'BK', 'WHITE': 'WH', 'IVORY': 'IV', 'ECRU': 'EC', 'CREAM': 'CR',
    'BEIGE': 'BE', 'LIGHT BEIGE': 'LB', 'DARK BEIGE': 'DB', 'CAMEL': 'CA',
    'BROWN': 'BR', 'DARK BROWN': 'DW', 'MELANGE BROWN': 'MB',
    'MELANGE BEIGE': 'ME', 'CHARCOAL': 'CH', 'KHAKI': 'KH',
    'OLIVE': 'OL', 'GRAY': 'GR', 'GREY': 'GR', 'MELANGE GRAY': 'MG',
    'MELANGE GREY': 'MG', 'LIGHT GRAY': 'LG', 'DARK GRAY': 'DG',
    'NAVY': 'NA', 'BLUE': 'BL', 'LIGHT BLUE': 'LB', 'SKY BLUE': 'SB',
    'PINK': 'PI', 'RED': 'RE', 'GREEN': 'GN', 'MINT': 'MT', 'PURPLE': 'PU',
    'WINE': 'WI', 'ORANGE': 'OR',
}


def _http_url(url):
    parts = urllib.parse.urlsplit(url.strip())
    if parts.scheme not in ('http', 'https') or not parts.hostname:
        raise ValueError('http 또는 https URL을 입력하세요.')
    return parts


def _referer(url):
    host = (urllib.parse.urlsplit(url).hostname or '').lower()
    if host.endswith('godohosting.com'):
        return 'https://indongfn.godohosting.com/'
    if host.endswith('cafe24img.com') or host.endswith('idfmall.co.kr') or host.endswith('poxo.com'):
        return 'https://idfmall.co.kr/'
    return urllib.parse.urlunsplit((*urllib.parse.urlsplit(url)[:2], '/', '', ''))


def _opener():
    jar = http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))


def _decode_body(raw, encoding):
    enc = (encoding or '').lower()
    if enc == 'gzip':
        return gzip.decompress(raw)
    if enc == 'deflate':
        try:
            return zlib.decompress(raw)
        except zlib.error:
            return zlib.decompress(raw, -zlib.MAX_WBITS)
    return raw


class _ImageURLParser(HTMLParser):
    def __init__(self, page_url):
        super().__init__(convert_charrefs=True)
        self.page_url = page_url
        self.urls = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        for key in ('src', 'data-src', 'data-original', 'data-lazy-src', 'href'):
            value = attrs.get(key, '')
            if value:
                self._add(value)
        for key in ('srcset', 'data-srcset'):
            for item in attrs.get(key, '').split(','):
                if item.strip():
                    self._add(item.strip().split()[0])

    def _add(self, value):
        value = value.strip().strip('"\'')
        if not value or value.startswith(('data:', 'javascript:')):
            return
        candidate = urllib.parse.urljoin(self.page_url, value.replace('\\/', '/'))
        if urllib.parse.urlsplit(candidate).scheme in ('http', 'https'):
            self.urls.append(candidate)


class _ProductOptionsParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.groups = []
        self.current = None

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'ul' and attrs.get('product_type') == 'product_option':
            self.current = {'title': attrs.get('option_title', ''), 'values': []}
            self.groups.append(self.current)
        elif tag == 'li' and self.current:
            value = attrs.get('option_value')
            if value and value not in self.current['values']:
                self.current['values'].append(value)

    def handle_endtag(self, tag):
        if tag == 'ul':
            self.current = None


def get_product_colors(html):
    parser = _ProductOptionsParser()
    parser.feed(html)
    color_group = next((g for g in parser.groups
                        if 'color' in g['title'].lower() or '색상' in g['title']), None)
    if color_group and color_group['values']:
        return color_group['values']
    # Fallback to the public ProductGroup metadata used by some IDF pages.
    for raw in re.findall(r'<script[^>]*type=["\']application/ld\+json["\'][^>]*>(.*?)</script>', html, re.I | re.S):
        try:
            obj = json.loads(raw)
        except (ValueError, TypeError):
            continue
        objects = obj if isinstance(obj, list) else [obj]
        for item in objects:
            if item.get('@type') == 'ProductGroup':
                return list(dict.fromkeys(v.get('color') for v in item.get('hasVariant', []) if v.get('color')))
    return []


def get_product_style_code(html):
    for raw in re.findall(r'<script[^>]*type=["\']application/ld\+json["\'][^>]*>(.*?)</script>', html, re.I | re.S):
        try:
            obj = json.loads(raw)
        except (ValueError, TypeError):
            continue
        objects = obj if isinstance(obj, list) else [obj]
        for item in objects:
            if item.get('@type') == 'ProductGroup':
                match = re.search(r'([A-Z]{2,}[A-Z0-9]*\d{3,})$', item.get('name', ''))
                if match:
                    return match.group(1)
    raise ValueError('상품 페이지에서 스타일 코드를 찾지 못했습니다.')


def find_color_images(style_code, color):
    color_key = ' '.join(color.upper().split())
    color_code = COLOR_CODES.get(color_key)
    if not color_code:
        # Most IDF color asset folders use a two-letter color abbreviation.
        color_code = ''.join(word[0] for word in color_key.split())[:2]
    # The IDF mall gallery numbers images sequentially within the selected
    # color folder; stop at the first four-image run used by the gallery.
    for year in ('2026', '2025', '2024'):
        run = []
        for index in range(1, 41):
            image_url = 'https://idfmall.co.kr/web/product/{}/{}/{}/{}_{}_{}.jpg'.format(
                year, style_code, color_code, style_code, color_code, index)
            try:
                with _fetch(image_url, 'image/*,*/*;q=0.8', method='HEAD') as response:
                    valid = response.status == 200 and response.headers.get('Content-Type', '').lower().startswith('image/')
            except Exception:
                valid = False
            if valid:
                run.append(image_url)
                if len(run) == 4:
                    return run
            else:
                run = []
    raise ValueError('이 색상의 사진 4장을 찾지 못했습니다. 자사몰의 사진 등록 방식이 다른 상품일 수 있습니다.')


def extract_image_urls(html, page_url):
    parser = _ImageURLParser(page_url)
    parser.feed(html)
    # IDF pages also embed image URLs in inline JSON/script strings.
    pattern = r'''(?:https?:)?//[^\s"'<>\\]+?\.(?:jpg|jpeg|png|webp|gif)(?:\?[^\s"'<>\\]*)?|(?:/(?:web/)?[^\s"'<>\\]+?\.(?:jpg|jpeg|png|webp|gif)(?:\?[^\s"'<>\\]*)?)'''
    for value in re.findall(pattern, html, re.IGNORECASE):
        parser._add(value)
    skip = ('logo', 'icon', 'banner', 'button', 'btn', 'arrow', 'loading', 'empty', 'bg_',
            'upload/category', 'upload/custom', 'facto/', '/big/', 'popup', 'sns', 'search',
            'header', 'footer', 'nav', 'menu', 'review', 'grade', 'star')
    candidates = []
    seen = set()
    for value in parser.urls:
        low = value.lower()
        host = (urllib.parse.urlsplit(value).hostname or '').lower()
        if not (host.endswith(('idfmall.co.kr', 'cafe24img.com', 'godohosting.com', 'poxo.com'))):
            continue
        if any(word in low for word in skip) or low in seen:
            continue
        seen.add(low)
        candidates.append(value)
    candidates.sort(key=lambda value: (0 if '/extra/small/' in value.lower() else 1, value.lower()))
    # Keep the Studio behavior: stable unique filenames and a small useful set.
    result, names = [], set()
    for value in candidates:
        name = urllib.parse.urlsplit(value).path.rsplit('/', 1)[-1].lower()
        if name and name not in names:
            names.add(name)
            result.append(value)
    return result


def _fetch(url, accept, method='GET'):
    _http_url(url)
    opener = _opener()
    req = urllib.request.Request(url, method=method, headers={
        'User-Agent': USER_AGENT, 'Accept': accept,
        'Accept-Language': 'ko-KR,ko;q=0.9,en;q=0.8',
        'Referer': _referer(url),
    })
    try:
        return opener.open(req, timeout=20)
    except urllib.error.URLError as exc:
        # Match the reference tool's legacy-host workaround only when certificate
        # verification itself fails; normal TLS verification remains the default.
        reason = getattr(exc, 'reason', None)
        if not isinstance(reason, ssl.SSLCertVerificationError):
            raise
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        return urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()),
            urllib.request.HTTPSHandler(context=ctx)).open(req, timeout=20)


def _image_type(data, header):
    content_type = (header or '').split(';', 1)[0].strip().lower()
    signatures = ((b'\xff\xd8\xff', 'image/jpeg'), (b'\x89PNG\r\n\x1a\n', 'image/png'),
                  (b'GIF87a', 'image/gif'), (b'GIF89a', 'image/gif'),
                  (b'BM', 'image/bmp'))
    detected = next((mime for sig, mime in signatures if data.startswith(sig)), None)
    if data.startswith(b'RIFF') and data[8:12] == b'WEBP':
        detected = 'image/webp'
    if len(data) >= 12 and data[4:8] == b'ftyp' and data[8:12] in (b'avif', b'avis'):
        detected = 'image/avif'
    if detected:
        return detected
    if content_type in IMAGE_TYPES:
        raise ValueError('응답의 Content-Type은 이미지지만 파일 형식이 올바르지 않습니다.')
    if content_type in ('text/html', 'application/json', 'text/plain') or not content_type.startswith('image/'):
        raise ValueError('이미지가 아닌 응답입니다 (Content-Type: {}). 주소, 접근 권한 또는 서버 응답을 확인하세요.'.format(content_type or '없음'))
    raise ValueError('지원하지 않는 이미지 형식입니다: {}'.format(content_type))

class Handler(http.server.SimpleHTTPRequestHandler):

    def do_GET(self):
        # 이미지 프록시
        if self.path.startswith('/proxy'):
            parsed = urllib.parse.urlparse(self.path)
            params = urllib.parse.parse_qs(parsed.query)
            target_url = params.get('url', [None])[0]
            if not target_url:
                self.send_error(400, "Missing url")
                return
            try:
                with _fetch(target_url, 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8') as resp:
                    data = resp.read(25 * 1024 * 1024 + 1)
                    if len(data) > 25 * 1024 * 1024:
                        raise ValueError('이미지가 25MB를 초과합니다.')
                    ct = _image_type(data, resp.headers.get('Content-Type'))
                self.send_response(200)
                self.send_header('Content-Type', ct)
                self.send_header('Content-Length', str(len(data)))
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                self.wfile.write(data)
            except Exception as e:
                self.send_response(502)
                self.send_header('Content-Type', 'text/plain; charset=utf-8')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                self.wfile.write(('이미지 프록시 실패: ' + str(e)).encode('utf-8', errors='replace'))
            return

        # Color-specific IDF mall gallery photos
        if self.path.startswith('/extract_color_images'):
            params = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            target_url = params.get('url', [None])[0]
            color = params.get('color', [''])[0].strip()
            try:
                if not target_url or not color:
                    raise ValueError('상품 URL과 색상을 입력하세요.')
                host = (urllib.parse.urlsplit(target_url).hostname or '').lower()
                if not host.endswith('idfmall.co.kr'):
                    raise ValueError('색상별 자동 추출은 IDF몰 상품 링크에서만 지원합니다.')
                with _fetch(target_url, 'text/html,application/xhtml+xml,*/*;q=0.8') as resp:
                    raw = resp.read(8 * 1024 * 1024 + 1)
                    if len(raw) > 8 * 1024 * 1024:
                        raise ValueError('상품 페이지가 8MB를 초과합니다.')
                    html = _decode_body(raw, resp.headers.get('Content-Encoding')).decode('utf-8', errors='replace')
                colors = get_product_colors(html)
                matched = next((value for value in colors if value.casefold() == color.casefold()), None)
                if not matched:
                    raise ValueError('상품 페이지에서 {} 색상을 찾지 못했습니다.'.format(color))
                style_code = get_product_style_code(html)
                images = find_color_images(style_code, matched)
                result = {'ok': True, 'color': matched, 'images': images}
                status = 200
            except Exception as e:
                result = {'ok': False, 'error': '{}: {}'.format(type(e).__name__, e)}
                status = 502
            self.send_response(status)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(json.dumps(result, ensure_ascii=False).encode('utf-8'))
            return

        # 모델컷 자동 추출
        if self.path.startswith('/extract_images'):
            parsed = urllib.parse.urlparse(self.path)
            params = urllib.parse.parse_qs(parsed.query)
            target_url = params.get('url', [None])[0]
            if not target_url:
                self.send_error(400, "Missing url")
                return
            try:
                with _fetch(target_url, 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8') as resp:
                    raw = resp.read(8 * 1024 * 1024 + 1)
                    if len(raw) > 8 * 1024 * 1024:
                        raise ValueError('상품 페이지가 8MB를 초과합니다.')
                    html = _decode_body(raw, resp.headers.get('Content-Encoding')).decode('utf-8', errors='replace')
                    page_url = resp.geturl()
                finals = extract_image_urls(html, page_url)
                colors = get_product_colors(html)
                result = json.dumps({'ok': True, 'images': finals[:8], 'total': len(finals), 'colors': colors}, ensure_ascii=False)
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                self.wfile.write(result.encode())
            except Exception as e:
                err = json.dumps({'ok': False, 'error': '{}: {}'.format(type(e).__name__, e)}, ensure_ascii=False)
                self.send_response(502)
                self.send_header('Content-Type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                self.wfile.write(err.encode())
            return

        super().do_GET()

    def do_POST(self):
        if self.path == '/save':
            length = int(self.headers.get('Content-Length', 0))
            body = self.rfile.read(length)
            try:
                data = json.loads(body)
                folder = data.get('folder', '').strip()
                filename = data.get('filename', 'output.jpg').strip()
                img_b64 = data.get('image', '')
                if ',' in img_b64:
                    img_b64 = img_b64.split(',')[1]
                img_bytes = base64.b64decode(img_b64)
                if folder:
                    os.makedirs(folder, exist_ok=True)
                    save_path = os.path.join(folder, filename)
                else:
                    save_path = filename
                with open(save_path, 'wb') as f:
                    f.write(img_bytes)
                result = json.dumps({'ok': True, 'path': save_path})
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                self.wfile.write(result.encode())
            except Exception as e:
                err = json.dumps({'ok': False, 'error': str(e)})
                self.send_response(500)
                self.send_header('Content-Type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                self.wfile.write(err.encode())
            return
        self.send_error(404)

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def log_message(self, format, *args):
        pass


def open_browser(port):
    import time
    time.sleep(0.8)
    webbrowser.open("http://localhost:{}/{}".format(port, HTML_FILE))


def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(script_dir)

    if not os.path.exists(HTML_FILE):
        print("[오류] {} 파일이 없습니다. 같은 폴더에 넣어주세요.".format(HTML_FILE))
        input("아무 키나 누르면 종료...")
        sys.exit(1)

    port = PORT
    for p in range(PORT, PORT + 20):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind(('', p))
            s.close()
            port = p
            break
        except OSError:
            continue

    print("=" * 48)
    print("  Detail Page Composer  v2.0.0")
    print("=" * 48)
    print("  http://localhost:{}/{}".format(port, HTML_FILE))
    print("  종료: 이 창을 닫으세요")
    print("=" * 48)

    threading.Thread(target=open_browser, args=(port,), daemon=True).start()

    with socketserver.TCPServer(("", port), Handler) as httpd:
        httpd.allow_reuse_address = True
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n종료합니다.")

if __name__ == "__main__":
    main()
